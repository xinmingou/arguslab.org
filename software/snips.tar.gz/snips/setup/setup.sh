# !/bin/sh
# Checks for the required software and warns if the packages are
# missing and setup snips
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

if [  -f $SNIPS_ROOT/snips.conf ]
then
. $SNIPS_ROOT/snips.conf
    echo  "snips is already installed. If you continoue snips will be removed!"
    echo  "run setup to remove snips [Y|n]: "
    read ch
    if [ "$ch" = "n" ]
    then
	exit 0
    else
	echo 'uninstalling snips...'
	if [ -d $apache_dir/snipsInterface ] 
	then
	    if [ -w $apache_dir/snipsInterface ] 
	    then
		rm -rf $apache_dir/snipsInterface
	    else
		echo  "this will need higher priviliges!"
		sudo rm -rf $apache_dir/snipsInterface
	    fi
	fi
	rm -f $SNIPS_ROOT/bin/snips.sh
	rm -f $SNIPS_ROOT/hostConfig.P
	rm -f $SNIPS_ROOT/bin/*.log
	rm -f $SNIPS_ROOT/src/core/analysis/libutils.xwam
	rm -f $SNIPS_ROOT/src/core/analysis/mode.xwam
	rm -f $SNIPS_ROOT/src/core/analysis/reason.xwam
	rm -f $SNIPS_ROOT/src/core/analysis/summary_db3.xwam
	rm -f $SNIPS_ROOT/kb/internal_model3.xwam
	rm -f $SNIPS_ROOT/kb/obsMap_snort.xwam
	rm -f $SNIPS_ROOT/hostConfig.xwam
	sh  $SNIPS_ROOT/setup/remove_snips_db.sh
	rm -f $SNIPS_ROOT/snips.conf
	(cd $SNIPS_ROOT/src/core/main/; make -s clean; cd $SNIPS_ROOT)
	echo
	echo
	echo  "do you want to re-run setup snips now [Y|n]:"
	read ch2
	if [ "$ch2" = "n" ]
	then
	    exit 0
	fi
    fi
fi

ERROR=0
RED_ERROR="$(tput setaf 1) ERROR $(tput sgr0)"
#checking system requirements
echo
echo
echo  'Checking for XSB... ' 
XSB=`which xsb`
if [ -z $XSB ] 
then
    echo  "$RED_ERROR: xsb not found. Please, install xsb OR add xsb to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi
echo
echo  'Checking for Python... '
PYTHON=`which python`
if [ -z $PYTHON ]
then
    echo  "$RED_ERROR: python not found. Please, install Python OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
    echo
    echo  'Checking for Python MySQLdb module... '
    cat >.sql_test.py<<EOF
try:
    import MySQLdb
    print 1,
except ImportError:
    print 0,
EOF
    moduleCheck=`python .sql_test.py`
    if [ $moduleCheck -ne 1 ]
    then
	echo "$RED_ERROR: Python MySQLdb module not found. Please, install python-mysqldb"
	ERROR=1
    else
	echo 'yes'
    fi
    rm .sql_test.py
fi
echo
echo  'Checking for Snort... ' 
SNORT=`which snort`
if [ -z $SNORT ] 
then
    echo  "$RED_ERROR: snort not found. Please, install Snort with mysql db support OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  "yes,$(tput setaf 2) make sure that snort output to mysql $(tput sgr0)"
fi
echo
echo  'Checking for Mysql... ' 
MYSQL=`which mysql`
if [ -z $MYSQL ] 
then
    echo  "$RED_ERROR: mysql server not found. Please, install Mysql server OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi
echo
echo  'Checking for Graphviz... ' 
DOT=`which dot`
if [ -z $DOT ] 
then
    echo  "$RED_ERROR: Graphviz not found. Please, install Graphviz OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi
echo
echo  'Checking for Java... ' 
JAVA=`which java`
if [ -z $JAVA ] 
then
    echo  "$RED_ERROR: java not found. Please, install Java OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi
echo
echo  'Checking for Javac... ' 
JAVAC=`which javac`
if [ -z $JAVAC ] 
then
    echo  "$RED_ERROR: javac not found. Please, install javac OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi
echo
echo  'Checking for Apache server... ' 
APACHE=`which apache2`
if [ -z $APACHE ] 
then
    echo  "$RED_ERROR: apache server not found. Please, install apache server OR add it to the 'PATH' eniroment variable"
    ERROR=1
else
    echo  'yes'
fi

#set up SNIPS_ROOT env variable
echo
echo  "checking for environment variable SNIPS_ROOT... "
cd ..
if [ -z $SNIPS_ROOT ]
then
    echo "$RED_ERROR: ENV variable not found. Please set SNIPS_ROOT evironment variable"
    ERROR=1
elif [ $PWD != $SNIPS_ROOT ] 
then
    echo "$RED_ERROR"
    echo "Env variable is wrong!"
    echo "Please fix 'SNIPS_ROOT' enviroment variable"
    ERROR=1
else 
    echo "yes"
    echo $SNIPS_ROOT
fi
cd $SNIPS_ROOT
#if there is some error
if [ $ERROR -eq 1 ]
then
    echo
    echo "do you want to setup snips with $(tput setaf 1)ERRORs $(tput sgr0) [Y|n]:"
    read ch2
    if [ "$ch2" = "n" ]
    then
	exit 0
    fi

fi

#now ask to continue if OK
echo
echo  "*********SnIPS has all what it need!*********"
echo
echo "Please enter snort rules enclosing directory path. This directory includes preproc_rules, rules, and so_rules directories. default: [/etc/snort]"
read snort_path  
if [ -z $snort_path ]
then
    snort_path=/etc/snort  
    echo "snort path is $snort_path"  
fi
# commented till the rules docs come back
# echo
# echo "Please enter snort rule documentation enclosing directory path. default: [/etc/snort/doc]"
# read snort_doc_path
# if [ -z $snort_doc_path ] 
# then
#     snort_doc_path=/etc/snort/doc
#     echo "snort rules documentation path is $snort_doc_path"  
# fi
###########detour 
#please remove the following after uncommenting the previous 
    snort_doc_path=$snort_path
####################ends
echo
echo "Please enter apache web directory path. default: [/var/www]"
read apache_dir
if [ -z $apache_dir ]
then
    apache_dir=/var/www  
    echo "apache web directory path is $apache_dir"  
fi


#create snips.conf
cp $SNIPS_ROOT/setup/snips.conf.in $SNIPS_ROOT/snips.conf
echo
echo "setup MySQL connection information..."
echo 'Please enter snort database name:'
read db_name
echo 'Please enter snort database user name:'
read db_user
echo 'Please enter snort database user password:'
read db_pass

#create output_dot_file path
output_dot_file=$SNIPS_ROOT/bin/snips_out_ds.dot
python $SNIPS_ROOT/setup/conf_file_creator.py -u $db_user -p $db_pass -n $db_name -a $apache_dir -d $output_dot_file -f $SNIPS_ROOT/snips.conf

#create snips db
echo
echo "creating snips MySQL database..."
echo "snips will use snort database to create its tables [Y|n]:"
read mysql
if [ "$mysql" = "n" ]
then
    echo
    echo "setup will assume the database is already created!"
    
else
    sh $SNIPS_ROOT/setup/create_snips_db.sh
    echo "snips tables created"
fi


#make java code and clean class files
echo
echo 'now makeing java code...'
mkdir $SNIPS_ROOT/setup/tmp
(cd $SNIPS_ROOT/setup/getIpRange; make -s; cd $SNIPS_ROOT)
(cd $SNIPS_ROOT/src/core/main/; make -s; cd $SNIPS_ROOT)
echo "yes"
# call getIpRange to provide with ip range for you network that snips monitor and produce hostConfig.P.
echo
echo
java -cp $SNIPS_ROOT/setup/tmp getIpRange.GetIpRange $ip_ranges $SNIPS_ROOT/hostConfig.P
[ ! -f $SNIPS_ROOT/hostConfig.P ] && exit 0

# create user_interface 
echo
echo 
echo "setup user interface php code in $apache_dir directory..."
cp -r $SNIPS_ROOT/rsc/webInterface $SNIPS_ROOT/setup/tmp/snipsInterface
if [ -f $SNIPS_ROOT/setup/tmp/snipsInterface/dbConfig.php ] 
then
    rm $SNIPS_ROOT/setup/tmp/snipsInterface/dbConfig.php
fi
cp $SNIPS_ROOT/setup/dbConfig.php.in $SNIPS_ROOT/setup/tmp/snipsInterface/dbConfig.php
python $SNIPS_ROOT/setup/php_conf_creator.py -u $db_user -p $db_pass -n $db_name -s $snort_path -d $snort_doc_path -f $SNIPS_ROOT/setup/tmp/snipsInterface/dbConfig.php
chmod -R 755 $SNIPS_ROOT/setup/tmp/snipsInterface
 
cpSnipsInterface(){
    if [ -w $apache_dir ] 
    then
	cp -rp $SNIPS_ROOT/setup/tmp/snipsInterface $apache_dir 
    else
	echo  "this will need higher priviliges!"
	sudo cp -rp $SNIPS_ROOT/setup/tmp/snipsInterface $apache_dir
    fi
}

if [ ! -d $apache_dir/snipsInterface ] && [ ! -f $apache_dir/snipsInterface ];
then
#call the copy function
    cpSnipsInterface
else
    echo "old $apache_dir/snipsInterface will be renamed [Y|n]:"
    read re_snipsInterface
    if [ "$re_snipsInterface" = "n" ]
    then
	echo "ok"
    else
	if [ -w $apache_dir/snipsInterface ] 
	then
	    c_time=$(date +'%s')
	    mv $apache_dir/snipsInterface $apache_dir/snipsInterface_$c_time 
	else
	    echo  "this will need higher priviliges!"
	    c_time=$(date +'%s' -d $date)
	    sudo mv $apache_dir/snipsInterface $apache_dir/snipsInterface_$c_time 
	fi
    fi
#call the copy function
    cpSnipsInterface
fi
#write usage 
echo
echo "Setup is done"
echo
echo "$(tput setaf 2) Now you can run SnIPS using the shell script:
  $SNIPS_ROOT/bin/snips.sh $(tput sgr0)"
# echo "after running snips.sh, output can be found in \"http://localhost/snipsInterface/snipsMain.html\""
echo

#copy main script to bin folder
cp $SNIPS_ROOT/src/aux/snips.sh $SNIPS_ROOT/bin

#clean up
if [ -d $SNIPS_ROOT/setup/tmp ] 
then
rm -rf $SNIPS_ROOT/setup/tmp
fi