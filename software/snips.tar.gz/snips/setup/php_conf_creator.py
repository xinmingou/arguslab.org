#!/usr/bin/python
# Description:Python script to fetch the alerts from mysql database and write it
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os
from optparse import OptionParser

class ConfWriter:
    def __init__(self,db_user,db_pass,db_name,file_name,snort_path,snort_doc_path):
        self.db_user=db_user.strip('\'').strip('"')
        self.db_pass=db_pass.strip('\'').strip('"')
        self.db_name=db_name.strip('\'').strip('"')
        self.file_name=file_name
        self.snort_path=snort_path.strip('\'').strip('"')
        self.snort_doc_path=snort_doc_path.strip('\'').strip('"')
        
    def write_conf(self):
                fh = open (self.file_name, 'a')
                fh.write('\n')
                fh.write("$DB=\""+self.db_name+"\";")
                fh.write('\n')
                fh.write("$DB_LOGIN=\""+self.db_user+"\";")
                fh.write('\n')
                fh.write("$DB_PASSWORD=\""+self.db_pass+"\";")
                fh.write('\n')
                fh.write("$snort_path=\""+self.snort_path+"\";")
                fh.write('\n')
                fh.write("$snort_doc_path=\""+self.snort_doc_path+"\";")
                fh.write('\n')
                fh.write("?>")
                fh.write('\n')
                fh.close()


def main(cliargs):
    oparser = OptionParser()
    oparser.add_option("-f", "--out-file", dest="file_name",
                       help="conf file name",
                       default="snips.conf")
    oparser.add_option("-u", "--db-username", dest="db_user",
                       help="datatbase user name", default="")
    oparser.add_option("-p", "--db-pass", dest="db_pass",
                       help="datatbase user pass", default="")
    oparser.add_option("-n", "--db-name", dest="db_name",
                       help="datatbase name", default="")
    oparser.add_option("-s", "--snort-path", dest="snort_path",
                       help="snort path", default="/etc/snort/")
    oparser.add_option("-d", "--snort-doc-path", dest="snort_doc_path",
                       help="snort rule doc path", default="/etc/snort/doc/signatures/")
    oparser.add_option("-g", "--svg-file-path", dest="snort_doc_path",
                       help="snort rule doc path", default="/etc/snort/doc/signatures/")


    (options, args) = oparser.parse_args(cliargs)

#    print options
    cw = ConfWriter(db_user=options.db_user,db_pass=options.db_pass,db_name=options.db_name,file_name=options.file_name,snort_path=options.snort_path,snort_doc_path=options.snort_doc_path)
    
    cw.write_conf()
    
if __name__ == '__main__':
    main(sys.argv[1:])

