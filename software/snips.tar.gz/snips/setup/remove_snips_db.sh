# !/bin/sh
# This script will drop all snips tables.
# Author(s) : Loai Zomlot
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf  


echo "This script will drop all snips tables."
echo "snips tables will be dropped [Y|n]:"
read mysql
if [ "$mysql" = "n" ]
then
exit 0

fi


mysql --user=$db_user --password=$db_pass --host=$db_host $db_name -A <<EOF
DROP TABLE IF EXISTS $graphs_nodes_table;
DROP TABLE IF EXISTS $graphs_arcs_table; 
DROP TABLE IF EXISTS $skolem_map_table; 
DROP TABLE IF EXISTS $global_num_table; 
DROP TABLE IF EXISTS $alerts_table; 
DROP TABLE IF EXISTS $summary_table; 
DROP TABLE IF EXISTS  $summary_proof_step_table;
DROP TABLE IF EXISTS $internal_proof_step_table; 
EOF
