# This script create snips database schema, it reads the db conf from snips.conf file
# Author(s) : Loai Zomlot
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf


mysql --user=$db_user --password=$db_pass --host=$db_host $db_name -A <<EOF
CREATE TABLE IF NOT EXISTS $graphs_nodes_table (node_num INT UNSIGNED, skolem_id VARCHAR(10), bpa_true FLOAT, bpa_false FLOAT, rule_ids TEXT, fact TEXT, time_range TEXT);
CREATE TABLE IF NOT EXISTS $graphs_arcs_table (node_num_source INT UNSIGNED, node_num_dest INT UNSIGNED);
CREATE TABLE IF NOT EXISTS $skolem_map_table (skolem_id int,sid int,cid int);
CREATE TABLE IF NOT EXISTS $global_num_table (node_num INT UNSIGNED);
CREATE TABLE IF NOT EXISTS $alerts_table (sid INT UNSIGNED, cid INT UNSIGNED, belief FLOAT);
CREATE TABLE IF NOT EXISTS $summary_table (pred ENUM('suspicious','compromised','sendExploit','probeOtherMachine'),h1 VARCHAR(15),h2 VARCHAR(15), mode ENUM('u','p','l','c'), skolem_id INT UNSIGNED NOT NULL, snort_rule_id VARCHAR(10),start_time INT UNSIGNED NOT NULL, end_time INT UNSIGNED NOT NULL);
CREATE TABLE IF NOT EXISTS  $summary_proof_step_table (skolem_id INT UNSIGNED NOT NULL, snort_rule_id VARCHAR(15),mode ENUM('u','p','l','c'),pred ENUM('suspicious','compromised','sendExploit','probeOtherMachine'),h1 VARCHAR(15),h2 VARCHAR(15),start_time INT UNSIGNED NOT NULL, end_time INT UNSIGNED NOT NULL);
CREATE TABLE IF NOT EXISTS $internal_proof_step_table (left_pred ENUM('suspicious','compromised','sendExploit','probeOtherMachine'), left_h1 VARCHAR(15), left_h2 VARCHAR(15), left_mode ENUM('u','p','l','c'), left_start_time INT UNSIGNED NOT NULL, left_end_time INT UNSIGNED NOT NULL, rule_Id VARCHAR(15), right_pred ENUM('suspicious','compromised','sendExploit','probeOtherMachine'), right_h1 VARCHAR(15), right_h2 VARCHAR(15), right_mode ENUM('u','p','l','c'), right_start_time INT UNSIGNED NOT NULL, right_end_time INT UNSIGNED NOT NULL, direction VARCHAR(15));
EOF





