#!/usr/bin/python
# Description:Python script to fetch the alerts from mysql database and write it
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os
from optparse import OptionParser

class ConfWriter:
    def __init__(self,db_user,db_pass,db_name,file_name,apache_dir,dot_file):
        self.dot_file=dot_file.strip('\'').strip('"')
        self.db_user=db_user.strip('\'').strip('"')
        self.db_pass=db_pass.strip('\'').strip('"')
        self.db_name=db_name.strip('\'').strip('"')
        self.apache_dir=apache_dir.strip('\'').strip('"')
        self.file_name=file_name

    def write_conf(self):
                fh = open (self.file_name, 'a')
                fh.write('\n')
                fh.write("output_dot_file="+self.dot_file)
                fh.write('\n')
                fh.write("apache_dir="+self.apache_dir)
                fh.write('\n')
                fh.write("db_name="+self.db_name)
                fh.write('\n')
                fh.write("db_user="+self.db_user)
                fh.write('\n')
                fh.write("db_pass="+self.db_pass)
                fh.close()


def main(cliargs):
    oparser = OptionParser()
    oparser.add_option("-f", "--out-file", dest="file_name",
                       help="conf file name",
                       default="snips.conf")
    oparser.add_option("-u", "--db-username", dest="db_user",
                       help="datatbase user name", default="")
    oparser.add_option("-p", "--db-pass", dest="db_pass",
                       help="datatbase user pass", default="")
    oparser.add_option("-n", "--db-name", dest="db_name",
                       help="datatbase name", default="")
    oparser.add_option("-a", "--apache-web-dir", dest="apache_dir",
                       help="apache web directory path", default="")
    oparser.add_option("-d", "--dot-file-path", dest="dot_file",
                       help="dot file path", default="")
    (options, args) = oparser.parse_args(cliargs)

#    print options
    cw = ConfWriter(db_user=options.db_user,db_pass=options.db_pass,db_name=options.db_name,file_name=options.file_name,apache_dir=options.apache_dir,dot_file=options.dot_file)
    cw.write_conf()
    
if __name__ == '__main__':
    main(sys.argv[1:])

