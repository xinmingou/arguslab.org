// main snips start class that calls correlation then do ds belief calculation then put the output in the db
// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package getIpRange;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GetIpRange {
	private static final String IP_PATTERN = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
			"([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
	private static final String IP_PATTERN_TWO_STARS = "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "(\\*\\.\\*)$";
	private static final String SUBNET_PATTERN = "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "((([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5]))|"
			+ "(\\*\\.\\*)|(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.\\*))";
	private static final String MULTIPLE_IPADDRESS_PATTERN = "^"
			+ SUBNET_PATTERN + "(," + SUBNET_PATTERN + ")*$";

	/**
	 * @param args
	 *            This will take ip range in this format 192.168.0.*,10.1.*.*
	 *            and so on with comma no more
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.out
			.println("usage:java -jar GetIpRange.jar ip outFileName"
					+ "java -jar GetIpRange.jar 192.168.1.1,192.1.68.* outFile");
			System.out.println();
			System.exit(0);
		}

		//read input ips
		Pattern pattern = Pattern.compile(MULTIPLE_IPADDRESS_PATTERN);
		BufferedReader reader;
		reader = new BufferedReader(new InputStreamReader(System.in));
		String inputIPs="";
		boolean flag=true;
		do{
			System.out.println("Please enter the subnet IP address...");
			System.out.println("For example, 192.168.*.*,192.168.5.* ");
			
			inputIPs = reader.readLine().trim();			
			Matcher matcher = pattern.matcher(inputIPs);
			if (!matcher.matches()) {
				flag=false;
				System.out.println("IP is not correct. Please re-enter");
				System.out.println("For example, 192.168.*.*,192.168.5.*  no more class B IP address and no spaces");
				System.out.println();
			}else{flag=true;}
		}while(flag!=true);
		
		
		String[] ipMasks = inputIPs.trim().split(",");
		// Create file
		FileWriter fstream = new FileWriter(args[0].trim());
		BufferedWriter out = new BufferedWriter(fstream);
		String fileTop="% !/bin/sh"+"\n"+
				"% main SnIPS script"+"\n"+
				"% Author: Loai Zomlot (lzomlot@ksu.edu)"+"\n"+
				"% 2011, Argus Cybersecurity Lab, Kansas State University" +"\n"+
				"" +"\n\n"+
				"hostConf(Host, internal):- " +"\n"+
				"internalHost(Host)," +"\n"+
				"!." +"\n\n"+
				"hostConf(Host, external):- " +"\n"+
				"not internalHost(Host)." +"\n"+
				"" +"\n";
		out.write(fileTop);
		for (int i = 0; i < ipMasks.length; i++) {
			String subnet = ipMasks[i].trim();
			String[] ipParts = subnet.split("\\.");
			if (Pattern.matches(IP_PATTERN, subnet)) {
				out.write("internalHost('" + subnet + "').");
				out.write("\n");
			} else if (Pattern.matches(IP_PATTERN_TWO_STARS, subnet)) {
				for (int i1 = 1; i1 < 255; i1++)
					for (int i11 = 1; i11 < 255; i11++) {
						out.write("internalHost('" + ipParts[0] + "."
								+ ipParts[1] + "." + i1 + "." + i11 + "').");
						out.write("\n");
					}
			}else{
				for (int i1 = 1; i1 < 255; i1++) {
					out.write("internalHost('" + ipParts[0] + "." + ipParts[1]
							+ "." + ipParts[2] + "." + i1 + "').");
					out.write("\n");
				}
			} 

		}
		// Close the output stream
		out.close();
	}

}


