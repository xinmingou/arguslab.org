<? 
/* reads snips graphs from db and presnt them in sorted manner */
/* Author(s) : Loai Zomlot  */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

ob_start(); ?>


<html>
<head>  
<title>Snips Graph Reader Website</title>


<!-- php functions -->

</head>
<body>
 <?
include("dbConfig.php");

if(isset($_GET["Threshold"]))
{
$Threshold =$_GET["Threshold"]; 
}else {
  $Threshold=0.5;
}  


/* connect to database */
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD); 
	
if($link == false)
  echo $DB_SERVER." DB NOT connected..."; 

$dbConnect = mysql_select_db($DB, $link) or die("database table cant be opened"); 

$sql= "select distinct node_num, skolem_id, bpa_true, bpa_false, rule_ids, fact, time_range
from " .$NODES_TABLE. "
where node_num != all (select node_num_source from " .$ARCS_TABLE. " ) order by bpa_true desc";
        
$result = mysql_query($sql, $link); 

$rows = mysql_num_rows($result);
if($rows == 0)
  echo "<br>"."No results are found...";


?>
<table align = "center">
  <tr height="5" style="height:5pt">
  <td align = "center"> <b><h2>Ranked Graph Sniks Nodes</h2></b></td>
  </tr>
  </table>
  <br>
  <table align = "center"> 
  <?
  for ($i=0; $i < $rows; $i+=1)
    {
      $j=$i+1;
      $bpaTrue=mysql_result($result, $i, "bpa_true");
     ?>
<tr><td>
      <font size = "4"> 

      <?echo $j.": "?> <a href=SnipsGraphNodeReader.php?NodeNum=<?echo mysql_result($result, $i, "node_num");?> style="text-decoration: none"> 
      <?echo "<font color='darkblue'>".mysql_result($result, $i, "fact")."</font>" ?>,  
<? if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?>, <a href=SnipsSnortRulesViewer.php?NodeNum=<?echo mysql_result($result, $i, "node_num")?> style="text-decoration: none"> Supporting snort rules </a> , Time <?echo mysql_result($result, $i, "time_range")?> </a>
</font>
</td></tr> 
<tr><td>  </td></tr>     
     
<? }?>


</table>

	<hr>
	</body>
	</html>