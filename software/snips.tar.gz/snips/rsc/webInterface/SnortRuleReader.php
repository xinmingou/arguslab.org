<? 
/* Author(s) : Tsung-Hsi Wu */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

ob_start(); ?>


<html>
<head>   
<title>Snort Rule Reader Website</title>

<?
include("dbConfig.php");

function dirList ($directory) 
{

    // create an array to hold directory list
    $results = array();

    // create a handler for the directory
    $handler = opendir($directory);

    // keep going until all files in directory have been read
    while ($file = readdir($handler)) {

        // if $file isn't this directory or its parent, 
        // add it to the results array
        if ($file != '.' && $file != '..')
            $results[] = $file;
    }

    // tidy up: close the handler
    closedir($handler);

    // done!
    return $results;

}

?>

<!-- php functions -->

</head>
<body>

<table align = "center">
<tr height="5" style="height:5pt">
   <td align = "center"> <b><h2>Snort Rule Reader</b></h2>   </td>
</tr>
</table>

<?
$path = $snort_path."/rules/"; 
$fileLists = array(); 
$counter = 0 ; 
$pos = 0 ; 
$next = 0 ; 


if(isset($_GET["SID"])&&isset($_GET["GID"]))
{
	$sid = $_GET["SID"];
 	$gid = $_GET["GID"];
	$results = dirList($path); 
	
	while(isset($results[$counter]))
  {	
    $path = $snort_path."/rules/".$results[$counter]; 
    
    if(file_exists($path))
	  {
	  	$fh = fopen($path, 'r');  	  	
	  	while(!feof($fh)) 
      {
      	$pos = 0 ; 
      	$theData = fgets($fh); 
	$SearchTerm = "sid:".$sid.";"; 
	      $pos = strpos($theData, $SearchTerm); 	      
	      if($pos > 0)
	      {	      	 	      	
	      	echo "<b>"."Snort Rule:"."</b>"."<br>"; 
	      	echo $theData; 	      	
	      	echo "<br>";
		echo "<a href=SnortRuleDescriptionReader.php?ruleID=".$_GET["SID"].">Rule Description</a>"; 
	       	break; 
	      }        
	    }	    
	    fclose($fh); 
	    $counter++; 	   	      
	  }	  
	  if($pos > 0)
	  {
	  	  $next = 1; 
	      break; 
	  }
  }	
  
  $counter = 0 ; 
  $path = $snort_path."/so_rules/"; 
  $results = dirList($path); 
  
  while(isset($results[$counter]) && $next == 0 )
  {	
    $path = $snort_path."/so_rules/".$results[$counter]; 
    
    if(file_exists($path))
	  {
	  	$fh = fopen($path, 'r');  	  	
	  	while(!feof($fh)) 
      {
      	$pos = 0 ; 
      	$theData = fgets($fh);
        $SearchTerm = "sid:".$sid."; gid:".$gid.";";
	      $pos = strpos($theData, $SearchTerm); 	      
	      if($pos > 0)
	      {	      	 	      	
	      	echo "<b>"."Snort Rule:"."</b>"."<br>"; 
	      	echo $theData; 	 
	      	echo "<br>";     	
	      	echo "<a href=SnortRuleDescriptionReader.php?ruleID=".$_GET["SID"].">Rule Description</a>"; 
		break; 
	      }       
	    }	    
	    fclose($fh); 
	    $counter++; 	   	      
	  }	  
	  if($pos > 0)
	  {
	      $next = 1;
	      break;
	  }
  }

 $counter = 0 ; 
  $path = $snort_path."/preproc_rules/"; 
  $results = dirList($path); 
  
  while(isset($results[$counter]) && $next == 0 )
  {	
    $path = $snort_path."/preproc_rules/".$results[$counter]; 
    
    if(file_exists($path))
	  {
	  	$fh = fopen($path, 'r');  
	  	
	  	while(!feof($fh)) 
      {
      	$pos = 0 ;
	$pos1 = 0;
      	$theData = fgets($fh);
	$SearchTerm_space = "sid: ".$sid."; gid: ".$gid.";";
	      $pos = strpos($theData, $SearchTerm); 
	      $pos1 = strpos($theData, $SearchTerm_space);
	      if(($pos > 0)||($pos1 > 0))
	      {	      	 	      	
	      	echo "<b>"."Snort Rule:"."</b>"."<br>"; 
	      	echo $theData; 	 
	      	echo "<br>";     	
		echo "<a href=SnortRuleDescriptionReader.php?ruleID=".$_GET["GID"]."-".$_GET["SID"].">Rule Description</a>";	
		break; 
	      }       
	    }	    
	    fclose($fh); 
	    $counter++; 	   	      
	  }	  
	  if(($pos > 0)||($pos1 > 0))
	      break; 
  }	
  
  echo "<hr>"."SearchTerm = "."<b>".$SearchTerm."</b>".".......Found in File Name: "."<b>".$results[$counter]."</b><br>"; 
}
else 
  echo "no file select"."<br>"; 
		
?>
<br><b>End of File...



</body>
</html>
