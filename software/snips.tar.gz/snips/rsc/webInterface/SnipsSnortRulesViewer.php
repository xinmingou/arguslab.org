<? 
/* Author(s) : Tsung-Hsi Wu*/
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

ob_start(); ?>


<html>
<head>  
<title>Snips Rules Viewer</title>


<!-- php functions -->

</head>
<body>
 <?
include("dbConfig.php");

//connect to database
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD);
	
if($link == false)
  echo $DB_SERVER." DB NOT connected...";
   
$dbConnect = mysql_select_db($DB, $link) or die("database table cant be opened");
   

if(isset($_GET["NodeNum"]))
    $node_num =$_GET["NodeNum"];

   //// first querey for the header
    $sql1 = "select * from " .$NODES_TABLE. " nt where " .$node_num."= nt.node_num";
    $result1 = mysql_query($sql1, $link);
    $rows1 = mysql_num_rows($result1);
    if($rows1 == 0)
      echo "<br>"."No results are found...";
    ?>
    <table align = "center">
       <tr height="5" style="height:5pt">
       <td align = "center"> <b><h3>Node(<?echo mysql_result($result1, $i, "fact")?>,  <? 
$bpaTrue=mysql_result($result1, $i, "bpa_true");
if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?> </a>)</h3></b></td>
       </tr>
       </table>
<hr>

    <table align = "center">
       <tr height="5" style="height:5pt">
       <td> <?echo mysql_result($result1, $i, "rule_ids")?> </a></td>
       </tr>
       </table>
<hr>
</body>
</html>