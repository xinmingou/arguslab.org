<?
/* Author(s) : Tsung-Hsi Wu, Loai Zomlot */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

 ob_start(); ?>


<html>
<head>


   
<title>Snort Rule Reader Website</title>


<!-- php functions -->

</head>
<body>

<?
include("dbConfig.php");
$path=$snort_doc_path."/signatures/";
if(isset($_GET["ruleID"]))
{
	$filename = $_GET["ruleID"]; 	
	$path = $path.$filename.".txt"; 
	
	
	if(file_exists($path))
	{
		
	  $fh = fopen($path, 'r');  
	  
	  
	  while (!feof($fh)) 
    {
	    $theData = fgets($fh);
	    echo $theData."<br>"; 	    
	  }
	  
	}
	else 
	  /* echo $filename.".txt does not exist";  */
	  echo "Rule description is not available!, because".$filename.".txt does not exist. Please, add the required file to the snort rule documentation directory";	
	
}
else 
  echo "no file select"."<br>"; 
		
		
?>

<br>
End of Description...



</body>
</html>
