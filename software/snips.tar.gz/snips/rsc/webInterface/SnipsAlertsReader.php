<?
/* read snort sorted alerts and present them  */
/* Author(s) : Loai Zomlot */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

 ob_start(); ?>


<html>
<head>  
<title>Snort Skolem Reader Website</title>


<!-- php functions -->

</head>
<body>

<?
include("dbConfig.php");

/* connect to database */
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD); 
	
	
	if($link == false)
	  echo $DB_SERVER." DB NOT connected..."; 
      
	$dbConnect = mysql_select_db($DB, $link) or die("database table cant be opened"); 

/* compute the number of pages */
$page_size=5000;
$sql = "select count(*)
   from ".$AlertsTable." sk, event e, iphdr i, signature si  
   where sk.cid=i.cid and sk.sid=i.sid and sk.cid=e.cid and sk.sid=e.sid and e.signature=si.sig_id";

$result = mysql_query($sql,$link); 
$row = mysql_fetch_row($result); 
$total_records = $row[0];
$total_pages = ceil($total_records / $page_size);


/* db query */
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; }; 

$start_from = ($page-1) * $page_size; 
$sql = "select belief, sk.sid, sk.cid, sig_gid, sig_sid, INET_NTOA(ip_src), INET_NTOA(ip_dst), timestamp 
   from ".$AlertsTable." sk, event e, iphdr i, signature si  
   where sk.cid=i.cid and sk.sid=i.sid and sk.cid=e.cid and sk.sid=e.sid and e.signature=si.sig_id 
   order by belief desc LIMIT " .$start_from.", ".$page_size;

	$result = mysql_query($sql, $link); 
	$rows = mysql_num_rows($result);
	if($rows == 0)
	  echo "<br>"."No results are found...";


	?>
<table align = "center">
  <tr height="5" style="height:5pt">
  <td align = "center"> <b><h2>Ranked Snort Alerts by Belief</h2></b></td>
  </tr>
  <tr >
	  <td align = "center"> <b> <?echo $total_records." alerts";?></b></td>
  </tr>
 <tr>
	  <td align = "center"> <b> Pages:<?
for ($i=1; $i<=$total_pages; $i++) {echo "<a href='SnipsAlertsReader.php?page=".$i."'>".$i." </a>"; };
?></b></td>
  </tr>
 </table>
  <br> <table align = "center"> 
   <?

for ($i=0; $i < $rows; $i+=1)
    {
      $j=$start_from+$i+1;
     $belief= mysql_result($result,$i,"belief");
    	  ?><tr><td>
	 <?echo $j.": "?>  <? if($belief >= $Threshold1) 
{echo "<font color='red'> Belief: ".$belief. "</font>";}
elseif($belief < $Threshold1 && $belief >= $Threshold2)
{echo "<font color='orange'> Belief: ".$belief. "</font>";}
elseif($belief < $Threshold2 && $belief >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$belief. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$belief. "</font>";}
?> obs(oid(<a href=SnortPayloadReader.php?sID=<?echo mysql_result($result,$i,"sid");?>&cID=<?echo mysql_result($result,$i,"cid");?>&dbName=<?echo $DB ;?>
	  ><? echo mysql_result($result,$i,"sid").", ";echo mysql_result($result,$i,"cid");?></a>),
          snort(<a href=SnortRuleReader.php?SID=<?echo mysql_result($result,$i,"sig_sid")?>&GID=<?echo mysql_result($result,$i,"sig_gid")?>>
<? echo mysql_result($result,$i,"sig_gid").":".mysql_result($result,$i,"sig_sid")?></a>, '<?echo mysql_result($result,$i,"INET_NTOA(ip_src)") ?>', '<? echo mysql_result($result,$i,"INET_NTOA(ip_dst)") ?>',  <? echo mysql_result($result,$i,"timestamp") ?>)).    		    		
   <? 

    }

?></td></tr></table>






</body>
</html>
