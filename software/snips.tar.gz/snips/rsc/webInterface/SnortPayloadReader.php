<? 
/* Author(s) : Tsung-Hsi Wu */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

ob_start(); ?>


<html>
<head>

<?

function hexToStr($hex)
{
    $string='';
    for ($i=0; $i < strlen($hex)-1; $i+=2)
    {
    		if((hexdec($hex[$i].$hex[$i+1]) >= hexdec("41") && hexdec($hex[$i].$hex[$i+1]) <= hexdec("5A")) || (hexdec($hex[$i].$hex[$i+1]) >= hexdec("61") && hexdec($hex[$i].$hex[$i+1]) <= hexdec("7A")))
    		{
        	$string .= chr(hexdec($hex[$i].$hex[$i+1]));
        }
        else if(hexdec($hex[$i].$hex[$i+1]) >= hexdec("30") && hexdec($hex[$i].$hex[$i+1]) <= hexdec("39"))
        {
        	$string .= chr(hexdec($hex[$i].$hex[$i+1]));
        }
        else
        {
        	$string .= ".";
        }
    }
    return $string;
}

function ShowPayload($payload)
{
  	echo "<br><br>";
    for ($i=0; $i < strlen($payload)-1; $i+=32)
    {
    		$tempString = substr($payload, $i, 32);
    		?> &nbsp; &nbsp; &nbsp; &nbsp; <?
    		
    		for($j=0 ; $j < strlen($tempString); $j+=2)
    		{
    			$hexString = substr($tempString, $j, 2);
    			echo "$hexString"; ?> &nbsp; &nbsp;&nbsp;&nbsp; <?
    		}
    		?> &nbsp; &nbsp;<?
    		echo hexToStr($tempString)."<br>";
    }
}

?>

   
<title>Snort Payload Reader Website</title>


<!-- php functions -->

</head>
<body>

<table align = "center">
<tr height="5" style="height:5pt">
   <td align = "center"> <b><h2>Snort Payload Reader</b></h2>   </td>
</tr>
</table>

<?
include("dbConfig.php");

/* connect to database */
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD); 
	
	
if($link != true){
	  echo $DB_SERVER." DB NOT connected..."; 
}

	$dbName = $_GET["dbName"]; 
	  
	$dbConnect = mysql_select_db($dbName, $link) or die("database table cant be opened"); 
	//echo "Open monaco database sucess"; 
	
	
/* connect to database */



if(isset($_GET["sID"])&&isset($_GET["cID"]))
{
	$cid = $_GET["cID"];
	$sid = $_GET["sID"];
	
	$sql = "SELECT * FROM data WHERE sid = ".$sid." and cid = ".$cid ;
        
	$result = mysql_query($sql, $link); 
	
	if(mysql_num_rows($result) > 0)
	{
	  echo "<br>"; 
	  echo "<b>sid</b>: ".mysql_result($result, 0, "sid")."<br><b>cid</b>: ".mysql_result($result, 0, "cid")."<br><b>payload</b>: ".mysql_result($result, 0, "data_payload"); 
	}
	else
	  echo "<br>"."No results are found...";

	$payloadHex = mysql_result($result, 0, "data_payload");
	//ShowPayload($payloadHex);
	
	?>
	<br>
	<table   align="center" width=100%>
  <tr>
   <td align ="center"><font size="4" ><b>Hex:</b> </font></td> 
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="center"><font size="3" color="#0000ff">&nbsp;&nbsp;&nbsp;</font></td>
   <td align ="left"><font size="4" ><b>Word Character</b> </font></td>
  </tr>
  
  <?
  for ($i=0; $i < strlen($payloadHex)-1; $i+=32)
    {
    	  ?><tr><td></td><?
    		$tempString = substr($payloadHex, $i, 32);
    		?> &nbsp; &nbsp; &nbsp; &nbsp; <?
    		
    		for($j=0 ; $j < 32; $j+=2)
    		{
    			if($j < strlen($tempString))
    			{
    			  $hexString = substr($tempString, $j, 2);
    			  ?><td align ="center"><font size="3" ><?echo $hexString;?></font></td><?
    			}
    			else
    			{
    			  ?><td></td><?
    			}
    		}
    		?><td></td><td align ="left"><font size="3" ><?echo hexToStr($tempString);?></font></td><?
    		//echo hexToStr($tempString)."<br>";
    		?></tr><?    		
    }
  ?></table<?
	
	
	
}
else 
  echo "no payload ID selected"."<br>"; 

		
?>

<hr>
end of the file...



</body>
</html>
