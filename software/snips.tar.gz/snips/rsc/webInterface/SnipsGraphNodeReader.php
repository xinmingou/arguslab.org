<?
/* read the parts of each snips graph */
/* Author(s) : Loai Zomlot  */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */

 ob_start(); ?>


<html>
<head>  
<title>Snips Nodes Reader Website</title>


<!-- php functions -->

</head>
<body>
 <?
include("dbConfig.php");


//connect to database
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD);
	
if($link == false)
  echo $DB_SERVER." DB NOT connected...";
   
$dbConnect = mysql_select_db($DB, $link) or die("database table cant be opened");
   

if(isset($_GET["NodeNum"]))
  {
    $node_num =$_GET["NodeNum"];
    

   //// first querey for the header
    $sql1 = "select * from " .$NODES_TABLE. " nt where " .$node_num."= nt.node_num";
    $result1 = mysql_query($sql1, $link);
    $rows1 = mysql_num_rows($result1);
    if($rows1 == 0)
      echo "<br>"."No results are found...";
    ?>
    <table align = "center">
       <tr height="5" style="height:5pt">
       <td align = "center"> <b><h3>Node(<?echo mysql_result($result1, $i, "fact")?>, <? 
$bpaTrue=mysql_result($result1, $i, "bpa_true");
if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?> </a>)</h3></b></td>
       </tr>
       </table>
<hr>
<?
 /////////////// incoming links

$sql2 = "select *
from " .$NODES_TABLE. " nt, (select at.node_num_source from " .$ARCS_TABLE. " at where at.node_num_dest=".$node_num.") snt
where nt.node_num = snt.node_num_source order by nt.bpa_true desc";
$result2 = mysql_query($sql2, $link);
$rows2 = mysql_num_rows($result2);
?>
<br>
  <table align = "center">
    <tr height="5" style="height:5pt">
       <td align = "center"> <b><h3>Supporting Hypothesis</h3></b></td>
       </tr>
<br>
<?
  for ($i=0; $i < $rows2; $i+=1)
    {
      $j=$i+1;
$bpaTrue=mysql_result($result2, $i, "bpa_true");
$skolemId=mysql_result($result2, $i, "skolem_id");
      if(is_null($skolemId)){ 
	  //if not skolem
 ?>      
<tr><td>
  <font size = "4">   <?echo $j.": "?> <a href=SnipsGraphNodeReader.php?NodeNum=<?echo mysql_result($result2, $i, "node_num");?> style="text-decoration: none"> 
      <?echo mysql_result($result2, $i, "fact")?>,  <? if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?>, <a href=SnipsSnortRulesViewer.php?NodeNum=<?echo mysql_result($result2, $i, "node_num")?> style="text-decoration: none"> Supporting snort rules </a>, Time <?echo mysql_result($result2, $i, "time_range")?> </a>
</font>
</td></tr> 
<tr><td>  </td></tr>     
<tr><td>  </td></tr>     
	  

<?}else{ //if skolem 
 ?>
<tr><td>
      <font size = "3">   <?echo $j.": "?> <a href=SnortSkolemReader.php?SkolemID=<?echo $skolemId."&TableName=".$TableName."&DBName=".$DB;?> style="text-decoration: none"> 
      <?echo "skolem(".$skolemId.")";?>, <? if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?>, Rules: <?echo mysql_result($result2, $i, "rule_ids")?> </a>
</font>
</td></tr> 
<tr><td>  </td></tr>     
    

<?
}
?>

  <?}?>   
</table>




<?
 /////////////// outgoing links

$sql3 = "select *
from " .$NODES_TABLE. " nt, (select at.node_num_dest from " .$ARCS_TABLE. " at where at.node_num_source=".$node_num.") snt
where nt.node_num = snt.node_num_dest order by nt.bpa_true desc";
$result3 = mysql_query($sql3, $link);
$rows3 = mysql_num_rows($result3);

?>
<br>
  <table align = "center">
    <tr height="5" style="height:5pt">
       <td align = "center"> <b><h3>Supported Hypothesis</h3></b></td>
       </tr>
<br>
<?
  for ($i=0; $i < $rows3; $i+=1)
    {
      $j=$i+1;
      $bpaTrue=mysql_result($result3, $i, "bpa_true");
 ?>      
<tr><td>
  <font size = "4">   <?echo $j.": "?> <a href=SnipsGraphNodeReader.php?NodeNum=<?echo mysql_result($result3, $i, "node_num");?> style="text-decoration: none"> 
      <?echo mysql_result($result3, $i, "fact")?>,  <? if($bpaTrue >= $Threshold1) 
{echo "<font color='red'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold1 && $bpaTrue >= $Threshold2)
{echo "<font color='orange'> Belief: ".$bpaTrue. "</font>";}
elseif($bpaTrue < $Threshold2 && $bpaTrue >= $Threshold3 )
{echo "<font color='gold'> Belief: ".$bpaTrue. "</font>";}
else 
 {echo "<font color='darkblue'> Belief: ".$bpaTrue. "</font>";}
?>, <a href=SnipsSnortRulesViewer.php?NodeNum=<?echo mysql_result($result3, $i, "node_num")?> style="text-decoration: none"> Supporting snort rules </a>, Time <?echo mysql_result($result3, $i, "time_range")?> </a>
</font>
</td></tr> 
<tr><td>  </td></tr>     


  <?}?>   
</table>




<?}else 
  echo "no node number founded"."<br>"; 
?>

</body>
</html>