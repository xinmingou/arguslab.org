<?
/* reads skolem snort alerts groups (skolem) 
Author(s) : Tsung-Hsi Wu */
/* Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University */

/* This program is free software: you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation, either version 3 of the License, or */
/* (at your option) any later version. */

/* This program is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the */
/* GNU General Public License for more details. */

/* You should have received a copy of the GNU General Public License */
/* along with this program.  If not, see <http://www.gnu.org/licenses/>. */
?>
<? ob_start(); ?>


<html>
<head>  
<title>Snort Skolem Reader Website</title>


<!-- php functions -->

</head>
<body>

<?
include("dbConfig.php");

/* connect to database */
$link = mysql_connect($DB_SERVER, $DB_LOGIN, $DB_PASSWORD); 
	
	
	if($link == false)
	 // echo $DB_SERVER." DB connected...";
	
	  echo $DB_SERVER." DB NOT connected..."; 
	
       if(isset($_GET["DBName"]))
      {
	$dbName =$_GET["DBName"]; 
      }  
	$dbConnect = mysql_select_db($dbName, $link) or die("database table cant be opened"); 


if(isset($_GET["SkolemID"])&&isset($_GET["TableName"]))
{
	$SkID = $_GET["SkolemID"];
	$Tname = $_GET["TableName"];
	$sql = "select sk.sid, sk.cid, sig_gid, sig_sid, INET_NTOA(ip_src),INET_NTOA(ip_dst),
            timestamp from  ".$Tname."  sk,event e,iphdr i, signature si 
            where sk.skolem_id=".$SkID." and sk.cid=i.cid and sk.sid=i.sid and sk.cid=e.cid and sk.sid=e.sid 
            and e.signature=si.sig_id";
        
	$result = mysql_query($sql, $link); 
	$rows = mysql_num_rows($result);
	if($rows == 0)
	  echo "<br>"."No results are found...";

	?>
  <table align = "center">
<tr height="5" style="height:5pt">
   <td align = "center"> <b><h2>Skolem(<? echo $SkID?>)</h2></b></td>
</tr>
</table>
<br>
 <table align = "center"> 
  <?
  for ($i=0; $i < $rows; $i+=1)
    {
    	  ?><tr><td>
             obs(oid(<a href=SnortPayloadReader.php?sID=<?echo mysql_result($result,$i,"sid");?>&cID=<?echo mysql_result($result,$i,"cid");?>&dbName=<?echo $dbName ;?>
	  ><? echo mysql_result($result,$i,"sid").", ";echo mysql_result($result,$i,"cid");?></a>),
          snort(<a href=SnortRuleReader.php?SID=<?echo mysql_result($result,$i,"sig_sid")?>&GID=<?echo mysql_result($result,$i,"sig_gid")?>>
<? echo mysql_result($result,$i,"sig_gid").":".mysql_result($result,$i,"sig_sid")?></a>, '<?echo mysql_result($result,$i,"INET_NTOA(ip_src)") ?>', '<? echo mysql_result($result,$i,"INET_NTOA(ip_dst)") ?>',  <? echo mysql_result($result,$i,"timestamp") ?>)).    		    		
   <? }?></td></tr></table><?
}
else 
  echo "no payload ID selected"."<br>"; 

		
?>

<hr>
end of the file...



</body>
</html>
