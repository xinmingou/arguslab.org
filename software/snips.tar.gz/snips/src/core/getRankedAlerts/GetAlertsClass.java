// get snort alerts from sorted snips graphs and put them in the db
// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.getRankedAlerts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import core.ds.DS;
import core.ds.DsStuff;
import core.ds.FrameOfDiscernment;
import core.ds.GraphWithScore;
import core.ds.Pair;
import core.graph.Arcs;
import core.graph.Mode;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.utils.Utilities;


public class GetAlertsClass {
	private  ArrayList<GraphWithScore> rankedGraphList;
	private DBInfo dbInfo;
	private  DsStuff[] ds;
	private  ArrayList<Alert> alertList=new ArrayList<Alert>();
	private Hashtable<String,ArrayList<Alert>> skolemMapHash;
	private Hashtable<String, Pair<Double,Double>> skolemBeliefHash=new Hashtable<String, Pair<Double,Double>>();

	public GetAlertsClass(ArrayList<GraphWithScore> graphs, DS  ds, DBInfo dbInfo) {
		this.rankedGraphList=graphs;
		this.ds=ds.ds_stuff_array;
		this.dbInfo=dbInfo;
		this.getSkolemMap();
		}

	private void getSkolemMap(){
		//get alerts from db
		DbConn db=new DbConn(dbInfo);
		db.getEvents();
		this.skolemMapHash=db.getSkolemMapHash();

	}

	public  ArrayList<Alert> getAlerts() {
		ArrayList<Alert> graphAlertList=new ArrayList<Alert>();
		for (GraphWithScore gwb : rankedGraphList) {
			this.getSkolemsBeliefs(gwb.getGraph().getNodes());
			graphAlertList=attachBeliefAndHighMode(this.skolemBeliefHash, gwb.getGraph().nodes);
			this.alertList.addAll(graphAlertList);
		}

		return this.alertList;
	}
	
	public int convertMode(Mode mode) {
		switch (mode) {
		case u:
			return 1;
		case p:
			return 2;
		case l:
			return 3;
		case c:
			return 4;
		default:
			System.out.println("error");
			break;
		}

		return 1;

	}
	
	private void getSkolemsBeliefs(ArrayList<SnipsNode> nodes) {
		for (SnipsNode node : nodes) {
			if (node instanceof Skolem) {
				if (!node.outGoing.isEmpty()) {
					if (node.outGoing.size()==1) {
						double ourBelief=getMaxBelief(node.outGoing.get(0).to,this.ds);
						this.skolemBeliefHash.put(((Skolem)node).Id,new Pair<Double, Double>(ourBelief,0.0) );
					}else{
						System.out.println("Skolem with multiple output!");
					}
				}
			}
		}
	}

	private Double getMaxBelief(SnipsNode node,DsStuff[] dsStuffArray) {
		if (!node.outGoing.isEmpty()) {
			for (Arcs arc : node.outGoing) {
				double maxBelief=dsStuffArray[node.nodeNum].getBpaTable().get(FrameOfDiscernment.True);
				double tmpBelief=getMaxBelief(arc.to, dsStuffArray);
				if (maxBelief < tmpBelief) {
					return tmpBelief;
				}	else{
					return maxBelief;
				}

			}
		}  
		double tmp = 0;
		if (Utilities.isSink(node)) {//sink node
			if (dsStuffArray[node.nodeNum]!=null) {
				HashMap<FrameOfDiscernment, Double> nodeBpaTable = dsStuffArray[node.nodeNum].getBpaTable();
				if (!nodeBpaTable.isEmpty()) {
					tmp=nodeBpaTable.get(FrameOfDiscernment.True);
				}

			}	
		}


		return tmp;

	}
	
	private ArrayList<Alert> attachBeliefAndHighMode(Hashtable<String, Pair<Double, Double>> skolemBeliefHash,ArrayList<SnipsNode> nodes) {
		ArrayList<Alert> skolemAlertList = null;
		ArrayList<Alert> totalAlertList=new ArrayList<Alert>();
		for (SnipsNode node : nodes) {
			if (node instanceof Skolem) {
				double ourBelief=skolemBeliefHash.get(((Skolem)node).Id).first;
				skolemAlertList=this.getGraphAlertsFromSkolem(node);
				for (Iterator<Alert> iterator = skolemAlertList.iterator(); iterator.hasNext();) {
					iterator.next().setBeliefAndHighModeAndMode(ourBelief,0.0,((Skolem)node).getMode());
				}
				totalAlertList.addAll(skolemAlertList);
			}
		}
		return totalAlertList;
	}

	private ArrayList<Alert> getGraphAlertsFromSkolem(SnipsNode node) {
		ArrayList<Alert> alertList=new ArrayList<Alert>();
		if (this.skolemMapHash.containsKey(((Skolem)node).Id)) {
			alertList.addAll(this.skolemMapHash.get(((Skolem)node).Id));
		}else{
//			System.out.println("Error in getting alerts from skolemMap!");
		}
		return alertList;	
	}

	
}
