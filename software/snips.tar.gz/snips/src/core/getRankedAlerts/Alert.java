// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.getRankedAlerts;

import java.sql.Timestamp;

import core.graph.Mode;
import core.utils.Utilities;


public class Alert {
	private Integer sid;
	private Integer cid;
	private double ourBelief; //the higheest beleif on the path
	private double standBelief; //the higheest beleif on the path
	private double modeValue;
	private Mode mode;
	private Timestamp timestamp;
	


	public Alert(Mode mode) {
		this.mode = mode;
		this.modeValue=Utilities.convertMode(mode);
	}

	public Alert(String sid, String cid) {
		this.sid=Integer.parseInt(sid.trim());
		this.cid=Integer.parseInt(cid.trim());
	}

	public Alert(String sid, String cid, Timestamp timestamp) {
		this.sid=Integer.parseInt(sid.trim());
		this.cid=Integer.parseInt(cid.trim());
		this.timestamp=timestamp;
	}

	public void setBeliefAndHighModeAndMode( double ourBelief,double standBelief, Mode mode){
		this.ourBelief = ourBelief;
		this.standBelief = standBelief;
		this.mode = mode;
		this.modeValue=Utilities.convertMode(mode);
	}

	public String getSidCide(){
		return sid.toString()+":"+cid.toString();
	}
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}


	public void setModeValue(double modeValue) {
		this.modeValue = modeValue;
	}

	public double getModeValue() {
		return modeValue;
	}


	public void setMode(Mode mode) {
		this.mode = mode;
		this.modeValue=Utilities.convertMode(mode);
	}


	public Mode getMode() {
		return mode;
	}

	
	public void setSid(Integer sid) {
		this.sid = sid;
	}


	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}


	public Timestamp getTimestamp() {
		return timestamp;
	}



	@Override
	public String toString() {
		return "Alert [sid=" + sid + ", cid=" + cid + ", ourBelief="
				+ ourBelief + ", standBelief=" + standBelief + ", modeValue="
				+ modeValue + ", mode=" + mode  + "]";
	}



	public double getOurBelief() {
		return ourBelief;
	}



	public void setOurBelief(double ourBelief) {
		this.ourBelief = ourBelief;
	}



	public double getStandBelief() {
		return standBelief;
	}



	public void setStandBelief(double standBelief) {
		this.standBelief = standBelief;
	}



}
