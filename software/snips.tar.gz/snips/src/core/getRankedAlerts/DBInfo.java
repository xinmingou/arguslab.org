// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.getRankedAlerts;

public final class DBInfo {

	public DBInfo(String dbUserName, String dbPassword, String skolemMapTable,
			String dbName, String alertsTable, String start_epoch_time, String end_epoch_time) {
		this.dbUserName = dbUserName;
		this.dbPassword = dbPassword;
		this.skolemMapTable = skolemMapTable;
		this.dbName = dbName;
		this.alertsTable=alertsTable;
		this.startEpochTime=start_epoch_time;
		this.endEpochTime=end_epoch_time;
	}
	public  String dbUserName;
	public  String dbPassword; 
	public  String skolemMapTable;
	public  String dbName;
	public String summProofStepTable;
	public String intProofStepTable;
	public String dataTable;
	public String alertsTable;
	public String startEpochTime;
	public String endEpochTime;

}
