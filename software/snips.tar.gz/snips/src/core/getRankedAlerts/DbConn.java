// database connnection class
// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.getRankedAlerts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;

import core.main.Snips3;


public class DbConn {
	private ArrayList<Alert> alertList = new ArrayList<Alert>();
	private Hashtable<String, ArrayList<Alert>> skolemMapHash = new Hashtable<String, ArrayList<Alert>>();
	private String skolemMapTable;
	private String dbName;
	private String userName;
	private String password;
	private String alertsTable;
	private ArrayList<Alert> alertListToWrite;
	private String startEpochTime;
	private String endEpochTime;

	public DbConn(DBInfo dbInfo) {
		this.skolemMapTable = dbInfo.skolemMapTable.trim();
		this.dbName = dbInfo.dbName.trim();
		this.userName = dbInfo.dbUserName.trim();
		this.password = dbInfo.dbPassword.trim();
		this.alertsTable = dbInfo.alertsTable.trim();
//		this.startEpochTime = dbInfo.startEpochTime.trim();
//		this.endEpochTime = dbInfo.endEpochTime.trim();
	}

	public DbConn(DBInfo dbInfo, ArrayList<Alert> alertList) {
		this.skolemMapTable = dbInfo.skolemMapTable.trim();
		this.dbName = dbInfo.dbName.trim();
		this.userName = dbInfo.dbUserName.trim();
		this.password = dbInfo.dbPassword.trim();
		this.alertsTable = dbInfo.alertsTable.trim();
		this.alertListToWrite = alertList;
//		this.startEpochTime = dbInfo.startEpochTime.trim();
//		this.endEpochTime = dbInfo.endEpochTime.trim();
	}

	public ArrayList<Alert> getEvents() {
		Connection conn = null;

		try {
			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName,
					this.password);
			queryDB(conn);
		} catch (Exception e) {
			System.err
					.println("Cannot connect to database server Alerts reader");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
		return alertList;

	}

	private void queryDB(Connection conn) {
//		int tableLimit = 100000;
		try {
//			// count the size of the skolem table to get
//			Statement s1 = conn.createStatement();
//			s1.executeQuery(" select count(*) from event where UNIX_TIMESTAMP(timestamp) >= "
//					+ this.startEpochTime
//					+ " and UNIX_TIMESTAMP(timestamp) <= " + this.endEpochTime);
//			ResultSet rs1 = s1.getResultSet();
//			rs1.first();
//			tableLimit+=(rs1.getInt(1)) ;

			// /get skolems
			Statement s = conn.createStatement();
			s.executeQuery("SELECT * FROM " + this.skolemMapTable);
//			s.executeQuery("SELECT * FROM " + this.skolemMapTable + " ORDER BY cid DESC LIMIT "
//					+ tableLimit);
			ResultSet rs = s.getResultSet();
			ArrayList<Alert> temp;
			while (rs.next()) {
				// skolemMapTable: skolem_id,sid,cid

				if (!this.skolemMapHash.containsKey(rs.getString(1))) {
					temp = new ArrayList<Alert>();
					temp.add(new Alert(rs.getString(2), rs.getString(3)));
					this.skolemMapHash.put(rs.getString(1), temp);
				} else {
					temp = this.skolemMapHash.get(rs.getString(1));
					temp.add(new Alert(rs.getString(2), rs.getString(3)));
					this.skolemMapHash.put(rs.getString(1), temp);
				}

			}
			rs.close();
			s.close();

		} catch (SQLException e) {
			System.err.println("Error message: " + e.getMessage());
			System.err.println("Error number: " + e.getErrorCode());
		}

	}

	// /write to alerts table
	public void writeAlerts() {
		Connection conn = null;

		try {
			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName,
					this.password);
			conn.setAutoCommit(false);
			this.cleanTable(conn);
			this.writeDB(conn);
		} catch (Exception e) {
			System.err
					.println("Cannot connect to database server alerts writer");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
	}

	private void cleanTable(Connection conn) {
		try {
			Statement s = conn.createStatement();
			s.executeUpdate("truncate " + this.alertsTable);
			s.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void writeDB(Connection conn) {
		PreparedStatement pstmt = null;
		String query = null;
		query = "insert into " + this.alertsTable
				+ "(sid, cid, belief) values(?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(query);
			for (Alert r : this.alertListToWrite) {
				pstmt.setInt(1, r.getSid());
				pstmt.setInt(2, r.getCid());
				pstmt.setFloat(3, (float) (this.roundTwoDecimals(r
						.getOurBelief())));
				pstmt.addBatch();
			}
			pstmt.executeBatch();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private double roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		return Double.valueOf(twoDForm.format(d));
	}

	public Hashtable<String, ArrayList<Alert>> getSkolemMapHash() {
		return skolemMapHash;
	}

	public void setSkolemMapHash(
			Hashtable<String, ArrayList<Alert>> skolemMapHash) {
		this.skolemMapHash = skolemMapHash;
	}
}
