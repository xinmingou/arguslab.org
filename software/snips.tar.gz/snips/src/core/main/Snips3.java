// main snips start class that calls correlation then do ds belief calculation then put the output in the db
// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.main;

import java.util.ArrayList;
import java.util.HashMap;

import core.correlation.CorrelationGraph;
import core.ds.DS;
import core.ds.FrameOfDiscernment;
import core.ds.GraphWithScore;
import core.ds.PrintToDB;
import core.ds.Print_Dot_DS;
import core.getRankedAlerts.Alert;
import core.getRankedAlerts.DBInfo;
import core.getRankedAlerts.DbConn;
import core.getRankedAlerts.GetAlertsClass;
import core.graph.Graph;
import core.graph.Graph_Trim;
import core.graph.SnipsGraph;
import core.utils.ConfigParam;
import core.utils.GlobalNodeNum;
import core.utils.ReadConfigFile;




public class Snips3 {
	static SnipsGraph snipsgraph = new SnipsGraph();
	public static DS ds;
	public static String urlHeader;
	public static HashMap<Integer, Integer> sinkMapper=new HashMap<Integer, Integer>();
	public static int globalNodeNum=0; //used externally when we write to the database, or dot files numbering of the nodes, because the arrays indexes will grow badly
	public static int currentGraphsNodeNumber=0;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		if (args.length !=1) {
			System.out.println("usage:java -jar SnipsGraph.jar snips.conf");
			System.exit(0);
		}
		ReadConfigFile.getParam(args[0]);
		boolean dsStandOrOur = false;		
		Snips3.urlHeader = "jdbc:mysql://"+ConfigParam.dbHost.trim()+"/";

		//get global node num
		GlobalNodeNum gnn=new GlobalNodeNum(ConfigParam.dbName, ConfigParam.dbUserName, ConfigParam.dbPassword, ConfigParam.globalNodeNumTable);
		Snips3.globalNodeNum=gnn.getGlobalNodeNum();

		// ********Create correlation Graph***
		initial(ConfigParam.summProofStepTable, ConfigParam.intProofStepTable, ConfigParam.dbName, ConfigParam.dbUserName, ConfigParam.dbPassword);

		// ************** Ds call **************
		ds=new DS(snipsgraph, dsStandOrOur);
		ArrayList<GraphWithScore> graphs= ds.rankGraphs(FrameOfDiscernment.True);

		///****print ds to dot files
		new Print_Dot_DS(ds).printToGraphVizFormatWithRank(graphs, ConfigParam.skolemMapTable, ConfigParam.dbName, ConfigParam.outputFilePath);

		////*****Print output in DB
		new PrintToDB(ConfigParam.dbName, ConfigParam.dbUserName, ConfigParam.dbPassword, ConfigParam.nodesTable, ConfigParam.arcsTable, ds, graphs).writeToDB();

		//*******Get the alerts and beliefs from graphs list
		DBInfo dbInfo=new DBInfo(ConfigParam.dbUserName, ConfigParam.dbPassword, ConfigParam.skolemMapTable, ConfigParam.dbName,ConfigParam.alertsTable,null,null);
		GetAlertsClass getAlerts=new GetAlertsClass(graphs, ds, dbInfo);
		ArrayList<Alert> alertList= getAlerts.getAlerts();
		new DbConn(dbInfo,alertList).writeAlerts();

		//set global node num
		gnn.setGlobalNodeNum(Snips3.globalNodeNum+Snips3.currentGraphsNodeNumber);

	}

	public static void initial(String summProofStepTable,
			String intProofStepTable, String dbName, String dbUserName,
			String dbPassword) {

		CorrelationGraph corrGraph=new CorrelationGraph();
		Graph g = corrGraph.createGraph(summProofStepTable,
				intProofStepTable, dbName, dbUserName, dbPassword);

		snipsgraph =Graph_Trim.reNumberGraph(Graph_Trim.removeCycle(Graph_Trim.Trim(Graph_Trim.removeExternal(g))));

	}
}
