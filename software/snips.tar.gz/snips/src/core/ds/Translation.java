// main translation class 
// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;
import java.util.HashMap;

import core.graph.Internal;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.utils.Utilities;

public class Translation {
	public  DsStuff ds_stuff_array[];
	
	public Translation(DsStuff[] ds_stuff_array) {
		new TranslationTable();
		this.ds_stuff_array=ds_stuff_array;
	}

	public DsStuff[] translate(SnipsNode node) {
		SnipsNode sourceNode = node.inComing.get(0).from;
		Internal currentNode = (Internal) node;
		if (sourceNode instanceof Skolem) {
			this.ds_stuff_array[currentNode.nodeNum]
					.setBpaTable(this.ds_stuff_array[sourceNode.nodeNum]
							.getBpaTable());
		} else {

			// *************************************
			// translate from table
			HashMap<FrameOfDiscernment, Double> sourceBpaTable = this.ds_stuff_array[sourceNode.nodeNum]
					.getBpaTable();

			for (FrameOfDiscernment sourceElement : sourceBpaTable.keySet()) {
				if (((Internal) sourceNode).fact.predicate.trim()
						.equalsIgnoreCase("sendExploit")
						&& sourceElement == FrameOfDiscernment.True) {
					this.splitTrueToSuccFailed(((Internal) sourceNode),
							currentNode, sourceBpaTable, sourceElement);
				} else {
					TranslationRow tempRow = buildTranslationRow(
							((Internal) sourceNode), currentNode,
							sourceElement, sourceBpaTable.get(sourceElement));
					tempRow = lookupTranslationTable(tempRow);
					addToDsStuffArray(tempRow, currentNode);
				}
			}
		}
		// *************************************
		// propagate the rule ids set to the current node
		this.ds_stuff_array[currentNode.nodeNum]
				.setRuleId(this.ds_stuff_array[sourceNode.nodeNum].getRuleId());
		this.ds_stuff_array[currentNode.nodeNum].setFact(((Internal) node).fact);
		
		return this.ds_stuff_array;
	}

	private void splitTrueToSuccFailed(Internal sourceNode,
			Internal currentNode,
			HashMap<FrameOfDiscernment, Double> sourceBpaTable,
			FrameOfDiscernment sourceElement) {
		TranslationRow tempRow;
		double succValue = sourceBpaTable.get(sourceElement) * 0.6;
		double failValue = sourceBpaTable.get(sourceElement) * 0.4;
		tempRow = buildTranslationRow(sourceNode, currentNode,
				FrameOfDiscernment.succeed, succValue);
		tempRow = lookupTranslationTable(tempRow);
		addToDsStuffArray(tempRow, currentNode);
		tempRow = buildTranslationRow(sourceNode, currentNode,
				FrameOfDiscernment.failed, failValue);
		tempRow = lookupTranslationTable(tempRow);
		addToDsStuffArray(tempRow, currentNode);
	}

	private void addToDsStuffArray(TranslationRow tempRow, SnipsNode currentNode) {
		// if the table has the same value

		if (this.ds_stuff_array[currentNode.nodeNum].getBpaTable().containsKey(
				tempRow.getGoalFrameElement())) {
			double tableValue = this.ds_stuff_array[currentNode.nodeNum]
					.getBpaTable().get(tempRow.getGoalFrameElement());
			double acumulatedValue = tableValue + tempRow.getGoalBpaValue();
			this.ds_stuff_array[currentNode.nodeNum].getBpaTable().put(
					tempRow.getGoalFrameElement(), acumulatedValue);
		} else {
			// create new field in the table
			this.ds_stuff_array[currentNode.nodeNum].getBpaTable().put(
					tempRow.getGoalFrameElement(), tempRow.getGoalBpaValue());
		}
	}

	protected TranslationRow buildTranslationRow(Internal sourceNode,
			Internal currentNode, FrameOfDiscernment sourceFrameElement,
			double sourceBpaValue) {

		// getting source node information
		String stringSourcePreds = sourceNode.fact.predicate;
		SnipsPredicate sourcePred = Utilities
				.convertToPredicate(stringSourcePreds);
		ArrayList<String> stringSourceArgsList = sourceNode.fact.argsList;

		// getting current node information
		SnipsPredicate currentPred = Utilities
				.convertToPredicate(((currentNode.fact.predicate)));
		ArrayList<String> stringCurrentArgsList = currentNode.fact.argsList;

		// convert IP values to IP enum
		Pair<ArgsList, ArgsList> argsLists = convertToIPEnum(
				stringSourceArgsList, stringCurrentArgsList);
		ArgsList sourceArgsList = argsLists.first;
		ArgsList currentArgsList = argsLists.second;

		return new TranslationRow(sourcePred, sourceArgsList,
				sourceFrameElement, sourceBpaValue, currentPred,
				currentArgsList);

	}

	private Pair<ArgsList, ArgsList> convertToIPEnum(
			ArrayList<String> stringSourceArgsList,
			ArrayList<String> stringCurrentArgsList) {
		ArgsList source = new ArgsList();
		ArgsList current = new ArgsList();

		if (stringCurrentArgsList.get(0).trim().equalsIgnoreCase(
				stringSourceArgsList.get(0).trim())) {
			source.setIp1(IP.source);
			source.setIp2(IP.any);
			current.setIp1(IP.source);

		} else { // the other case the second from one matches the first from
			// other

			current.setIp1(IP.destination);
			source.setIp1(IP.any);
			source.setIp2(IP.destination);

		}
		return new Pair<ArgsList, ArgsList>(source, current);
	}

	private boolean isEqualArgsLists(TranslationRow tempRow, TranslationRow row) {
		boolean flag1 = false, flag2 = false, flag3 = false;

		if (row.getArgsList().getIp1().equals(tempRow.getArgsList().getIp1())
				&& row.getGoalArgsList().getIp1().equals(
						tempRow.getGoalArgsList().getIp1())) {
			flag1 = true;
		}

		if (tempRow.getArgsList().size() == 2 && row.getArgsList().size() == 2) {
			if (row.getArgsList().getIp2().equals(
					tempRow.getArgsList().getIp2())) {
				flag2 = true;
			}
		} else {
			flag2 = true;
		}

		if (tempRow.getGoalArgsList().size() == 2
				&& row.getGoalArgsList().size() == 2) {
			if (row.getGoalArgsList().getIp2().equals(
					tempRow.getGoalArgsList().getIp2())) {
				flag3 = true;
			}
		} else {
			flag3 = true;
		}

		if (flag1 && flag2 && flag3) {
			return true;
		} else {
			return false;
		}

	}

	protected TranslationRow lookupTranslationTable(TranslationRow tempRow) {
		for (TranslationRow row : TranslationTable.translationTables) {

			if (row.getPred().equals(tempRow.getPred())
					&& row.getFrameElement().equals(tempRow.getFrameElement())
					&& row.getGoalPred().equals(tempRow.getGoalPred()))

				if (isEqualArgsLists(tempRow, row)) {

					tempRow.setGoalFrameElement(row.getGoalFrameElement());
					break;
				}
		}
		if (tempRow.getGoalFrameElement() == null) {
			System.out.println("no match with Translation table");
		}
		return tempRow;
	}

}
