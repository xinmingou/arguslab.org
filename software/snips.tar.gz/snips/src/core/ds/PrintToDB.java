// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import core.graph.Arcs;
import core.graph.Internal;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.main.Snips3;


public class PrintToDB  {
	int count=0;
	protected String dbName;
	protected String userName;
	protected String password;
	protected String nodesTable;
	protected String arcsTable;
	protected DS ds;
	protected ArrayList<GraphWithScore> graphs;


	public PrintToDB(String dbName, String userName, String password, 
			String nodesTable, String arcsTable, DS ds, ArrayList<GraphWithScore> graphs) {
		this.dbName = dbName.trim();
		this.userName = userName.trim();
		this.password = password.trim();
		this.nodesTable=nodesTable.trim();
		this.arcsTable=arcsTable.trim();
		this.ds=ds;
		this.graphs=graphs;
	}

	public void writeToDB() {
		Connection conn = null;
		try {

			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName, this.password);
			conn.setAutoCommit(false);
			this.write(conn);
		} catch (Exception e) {
			System.err.println("Cannot connect to database server");
		} finally {
			if (conn != null) {
				try {
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
	}

	private void write(Connection conn)  {
		try {
			Statement s = conn.createStatement();
			s.executeUpdate("truncate " + this.nodesTable);
			s.executeUpdate("truncate " + this.arcsTable);
			s.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		PreparedStatement pstmt=null;
		String query=null;

		Iterator<GraphWithScore> it1 = this.graphs.iterator();
		query = "insert into " + this.nodesTable +
				"(node_num, skolem_id, bpa_true, bpa_false, rule_ids, fact, time_range) values(?, ?, ?, ?, ?, ?, ?)";
		try {
			pstmt= conn.prepareStatement(query);
			while (it1.hasNext()) {
				Iterator<SnipsNode> no = it1.next().getGraph().nodes.iterator();
				while (no.hasNext()) {
					print_node(no.next(),conn, pstmt);
				}
			}
			pstmt.executeBatch();
			pstmt.close();		
		} catch (SQLException e) {
			e.printStackTrace();
		}	


		Iterator<GraphWithScore> it2 = this.graphs.iterator();
		query = "insert into " + this.arcsTable + "(node_num_source, node_num_dest) values(?, ?)";
		try {
			pstmt= conn.prepareStatement(query);

			while (it2.hasNext()) {
				Iterator<SnipsNode> ar = it2.next().getGraph().nodes.iterator();
				while (ar.hasNext())
					print_arc(ar.next(), conn,pstmt);
			}
			pstmt.executeBatch();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void print_node(SnipsNode node, Connection conn, PreparedStatement pstmt) {

		String skolemId=null;
		if (node instanceof Skolem) {
			Skolem skolem = (Skolem) node;
			skolemId=skolem.Id;
		}


		HashMap<FrameOfDiscernment, Double> nodeBpaTable = ds.ds_stuff_array[node.nodeNum]
				.getBpaTable();
		Double bpa_true=this.roundBpaTable(nodeBpaTable).get(FrameOfDiscernment.True);
		Double bpa_false=this.roundBpaTable(nodeBpaTable).get(FrameOfDiscernment.theta);
		if (bpa_true==null||bpa_false==null) {
			bpa_true=bpa_false=0.0;
		}
		String rule_ids=ds.ds_stuff_array[node.nodeNum].getRuleId().toString();
		String fact = getLabel(node);
		String time_range=null;
		if (node instanceof Internal) {
			Internal in = (Internal) node;
			time_range= "range(" + in.time.startTime + ", " + in.time.endTime + ")";	
		}

		try {
			pstmt.setInt(1, node.nodeNum+Snips3.globalNodeNum);
			pstmt.setString(2,skolemId);
			pstmt.setDouble(3,bpa_true);
			pstmt.setDouble(4,bpa_false);
			pstmt.setString(5, rule_ids);
			pstmt.setString(6, fact);
			pstmt.setString(7, time_range);
			pstmt.addBatch();

		} catch (SQLException e) {
			System.err.println("nodes table error!");
			e.printStackTrace();
		}
	}



	protected void print_arc(SnipsNode node, Connection conn, PreparedStatement pstmt) {
		if (!node.outGoing.isEmpty()) {
			Arcs arc = new Arcs();
			Iterator<Arcs> it;
			it = node.outGoing.iterator();

			while (it.hasNext()) {
				arc = it.next();
				try {
					pstmt.setInt(1, arc.from.nodeNum+Snips3.globalNodeNum);
					pstmt.setInt(2, arc.to.nodeNum+Snips3.globalNodeNum);
					pstmt.addBatch();
				} catch (SQLException e) {
					System.err.println("arcs table error!");
					e.printStackTrace();
				}
			}
		}
	}

	private String getLabel(SnipsNode node) {
		String t;
		if (node instanceof Skolem) {
			Skolem s = (Skolem) node;
			t = "skolem(" + s.Id + ", " + s.mode + ")";
			return t;
		} else if (node instanceof Internal) {
			Internal in = (Internal) node;
			t =  in.fact.predicate + "(";
			t += in.fact.argsList.get(0);
			if (in.fact.argsList.size() == 2)
				t += ", " + in.fact.argsList.get(1);
			t += ")";


			return t;
		}
		return null;
	}

	// rounding bpa table to 2 decimals
	private HashMap<FrameOfDiscernment, Double> roundBpaTable(
			HashMap<FrameOfDiscernment, Double> nodeBpaTable) {
		HashMap<FrameOfDiscernment, Double> nodeBpaTableRounded = new HashMap<FrameOfDiscernment, Double>();
		for (FrameOfDiscernment key : nodeBpaTable.keySet()) {
			Double temp = this.roundTwoDecimals(nodeBpaTable.get(key));
			nodeBpaTableRounded.put(key, temp);
		}
		return nodeBpaTableRounded;
	}

	private Double roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		return Double.valueOf(twoDForm.format(d));
	}

	//***getters and setters
	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNodesTable() {
		return nodesTable;
	}

	public void setNodesTable(String nodesTable) {
		this.nodesTable = nodesTable;
	}

	public String getArcsTable() {
		return arcsTable;
	}

	public void setArcsTable(String arcsTable) {
		this.arcsTable = arcsTable;
	}

	public DS getDs() {
		return ds;
	}

	public void setDs(DS ds) {
		this.ds = ds;
	}

	public ArrayList<GraphWithScore> getGraphs() {
		return graphs;
	}

	public void setGraphs(ArrayList<GraphWithScore> graphs) {
		this.graphs = graphs;
	}

}