// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import core.graph.Print_Dot;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.main.Snips3;



public class Print_Dot_DS extends Print_Dot {
	DS ds;

	public Print_Dot_DS(DS ds) {
		super();
		this.ds=ds;
	}

	public void printToGraphVizFormatWithRank(ArrayList<GraphWithScore> s,
			String table, String db, String outputFile) {
		if (outputFile == null) {
			outputFile = "snips_graph_ds.dot";
		} else {
			String tmpFile = outputFile.replaceAll(".dot", "_ds.dot");
			if (tmpFile.length() == outputFile.length()) {
				tmpFile = outputFile.concat("_ds.dot");
			}
			outputFile = tmpFile;
		}
		try {
			br = new BufferedWriter(new FileWriter(outputFile));
			br.write(open);
			br.newLine();
			Iterator<GraphWithScore> it1 = s.iterator();
			Iterator<GraphWithScore> it2 = s.iterator();

			while (it1.hasNext()) {
				GraphWithScore currentGraphWithScore = it1.next();
				Iterator<SnipsNode> no = currentGraphWithScore.getGraph().nodes
						.iterator();
				SnipsNode tempNode = null;

				while (no.hasNext()) {
					tempNode = no.next();
					print_node(tempNode, table, db);

				}
			}
			while (it2.hasNext()) {
				Iterator<SnipsNode> ar = it2.next().getGraph().nodes.iterator();
				while (ar.hasNext())
					print_arc(ar.next());
			}
			br.write(node_step);
			br.newLine();
			br.write("ranksep=" + rank_step);
			br.newLine();
			br.write(close);
			br.close();
		} catch (Exception e) {
		}

	}

	@Override
	protected void print_node(SnipsNode node, String table, String db) {
		int tempNodeNum;
		HashMap<FrameOfDiscernment, Double> nodeBpaTable = ds.ds_stuff_array[node.nodeNum]
				.getBpaTable();
		Node_lable = getLabel(node, 0);
		String URL = "";
		if (node instanceof Skolem) {
			Skolem s = (Skolem) node;
			URL = ",URL=\"" + "/snipsInterface/SnortSkolemReader.php?SkolemID="
					+ s.Id + "&TableName=" + table + "&DBName=" + db + "\"";
		}
		tempNodeNum=node.nodeNum+Snips3.globalNodeNum;
		try {
			br.write(tempNodeNum + tab + label + "\"" + "(BpaTable"
					+ this.roundBpaTable(nodeBpaTable).toString() + ")"
					+ "   :   " + "(ruleID"
					+ ds.ds_stuff_array[node.nodeNum].getRuleId().toString()
					+ ")" + "   :    " + tempNodeNum + ": " + Node_lable
					+ "\"" + URL + "," + "fontsize=" + node_fontsize + ","
					+ fontname + "," + node_fontcolor_red);
			br.newLine();
		} catch (Exception e) {
		}
	}

	// round bpa table to two decimals
	private HashMap<FrameOfDiscernment, Double> roundBpaTable(
			HashMap<FrameOfDiscernment, Double> nodeBpaTable) {
		HashMap<FrameOfDiscernment, Double> nodeBpaTableRounded = new HashMap<FrameOfDiscernment, Double>();
		for (FrameOfDiscernment key : nodeBpaTable.keySet()) {
			Double temp = this.roundTwoDecimals(nodeBpaTable.get(key));
			nodeBpaTableRounded.put(key, temp);
		}
		return nodeBpaTableRounded;
	}

	private Double roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		return Double.valueOf(twoDForm.format(d));
	}

}
