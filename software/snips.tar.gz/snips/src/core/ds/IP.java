// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

package core.ds;

public enum IP {
	source, destination, any;

}
