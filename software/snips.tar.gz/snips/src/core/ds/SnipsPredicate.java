// Author(s) : Loai Zomlot (lzomlot@ksu.edu)
// Copyright (C) 2011, Argus Cybersecurity Lab, Kansas State University

package core.ds;

public enum SnipsPredicate {

	probeOtherMachine, compromised, sendExploit;
}
