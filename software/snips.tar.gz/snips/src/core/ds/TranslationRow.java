// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

public class TranslationRow {

	private FrameOfDiscernment frameElement, goalFrameElement;
	private SnipsPredicate pred, goalPred;
	private ArgsList argsList, goalArgsList;
	private double bpaValue, goalBpaValue;

	/**
	 * for translation purposes
	 */
	public TranslationRow(SnipsPredicate pred, ArgsList argsList,
			FrameOfDiscernment frameElement, double bpaValue,
			SnipsPredicate goalPred, ArgsList goalArgsList) {
		this.pred = pred;
		this.frameElement = frameElement;
		this.argsList = argsList;
		this.goalPred = goalPred;
		this.goalArgsList = goalArgsList;
		this.bpaValue = bpaValue;
		this.goalBpaValue = this.computeGoalBpaValue(this.bpaValue);
		this.goalFrameElement = null;
	}

	/**
	 * for building the table
	 * 
	 * @param
	 */
	public TranslationRow(SnipsPredicate pred, ArgsList argsList,
			FrameOfDiscernment frameElement, SnipsPredicate goalPred,
			ArgsList goalArgsList, FrameOfDiscernment goalFrameElement) {
		this.pred = pred;
		this.frameElement = frameElement;
		this.argsList = argsList;
		this.goalPred = goalPred;
		this.goalArgsList = goalArgsList;
		this.bpaValue = 0;
		this.goalBpaValue = 0;
		this.goalFrameElement = goalFrameElement;
	}

	public ArgsList getArgsList() {
		return argsList;
	}

	public double getBpaValue() {
		return bpaValue;
	}

	public FrameOfDiscernment getFrameElement() {
		return frameElement;
	}

	public ArgsList getGoalArgsList() {
		return goalArgsList;
	}

	public double getGoalBpaValue() {
		return goalBpaValue;
	}

	public FrameOfDiscernment getGoalFrameElement() {
		return this.goalFrameElement;
	}

	public SnipsPredicate getGoalPred() {
		return goalPred;
	}

	public SnipsPredicate getPred() {
		return pred;
	}

	public void setArgsList(ArgsList argsList) {
		this.argsList = argsList;
	}

	public void setBpaValue(double bpaValue) {
		this.bpaValue = bpaValue;
	}

	public void setFrameElement(FrameOfDiscernment frameElement) {
		this.frameElement = frameElement;
	}

	public void setGoalArgsList(ArgsList goalArgsList) {
		this.goalArgsList = goalArgsList;
	}

	public void setGoalBpaValue(double goalBpaValue) {
		this.goalBpaValue = goalBpaValue;
	}

	public void setGoalFrameElement(FrameOfDiscernment goalFrameElement) {
		this.goalFrameElement = goalFrameElement;
	}

	public void setGoalPred(SnipsPredicate goalPred) {
		this.goalPred = goalPred;
	}

	public void setPred(SnipsPredicate pred) {
		this.pred = pred;
	}

	private double computeGoalBpaValue(double bpaValue2) {
		// translation rule said to map the number to the goal
		return bpaValue2;
	}

}
