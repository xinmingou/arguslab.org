// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;
import java.util.HashMap;

import core.graph.Fact;


public class DsStuff {

	private HashMap<FrameOfDiscernment, Double> bpaTable;
	private boolean visted = false;
	private Fact fact;
	private ArrayList<String> ruleId; // using the rule cid
	private int predCount;

	public DsStuff() {
		this.setBpaTable(new HashMap<FrameOfDiscernment, Double>());
		this.setRuleId(new ArrayList<String>());

	}

	public DsStuff(Integer predCountInitValue) {
		this.setPredCount(predCountInitValue);
		this.setBpaTable(new HashMap<FrameOfDiscernment, Double>());
		this.setRuleId(new ArrayList<String>());

	}

	public boolean isPredCountZeroNotVisited() {
		return ((getPredCount() == 0 && visted == false) ? true : false);
	}

	// ********************************************
	// getters and setters
	public void decreasePredCount() {
		this.setPredCount(this.getPredCount() - 1);

	}

	public void visted() {
		this.visted = true;

	}

	public void setPredCount(int predCount) {
		this.predCount = predCount;
	}

	public int getPredCount() {
		return predCount;
	}

	public void setFact(Fact fact) {
		this.fact = fact;
	}

	public Fact getFact() {
		return fact;
	}

	public void setRuleId(ArrayList<String> ruleId) {
		this.ruleId = ruleId;
	}

	public ArrayList<String> getRuleId() {
		return ruleId;
	}

	public void setBpaTable(HashMap<FrameOfDiscernment, Double> bpaTable) {
		this.bpaTable = bpaTable;
	}

	public HashMap<FrameOfDiscernment, Double> getBpaTable() {
		return bpaTable;
	}

}