// knowledge base for Dempster shafer calculations
// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;

public final class TranslationTable {

	public static ArrayList<TranslationRow> translationTables = new ArrayList<TranslationRow>();

	// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public TranslationTable() {

		translationTables.add(new TranslationRow(
				SnipsPredicate.probeOtherMachine, new ArgsList(IP.source,
						IP.any), FrameOfDiscernment.True,
				SnipsPredicate.compromised, new ArgsList(IP.source),
				FrameOfDiscernment.True));
		translationTables.add(new TranslationRow(
				SnipsPredicate.probeOtherMachine, new ArgsList(IP.source,
						IP.any), FrameOfDiscernment.theta,
				SnipsPredicate.compromised, new ArgsList(IP.source),
				FrameOfDiscernment.theta));

		// ////////////////////////////////////////////////////////

		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.source, IP.any), FrameOfDiscernment.failed,
				SnipsPredicate.compromised, new ArgsList(IP.source),
				FrameOfDiscernment.True));
		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.source, IP.any), FrameOfDiscernment.succeed,
				SnipsPredicate.compromised, new ArgsList(IP.source),
				FrameOfDiscernment.True));
		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.source, IP.any), FrameOfDiscernment.theta,
				SnipsPredicate.compromised, new ArgsList(IP.source),
				FrameOfDiscernment.theta));

		// ////////////////////////////////////////////////////////

		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.any, IP.destination),
				FrameOfDiscernment.failed, SnipsPredicate.compromised,
				new ArgsList(IP.destination), FrameOfDiscernment.theta));
		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.any, IP.destination),
				FrameOfDiscernment.succeed, SnipsPredicate.compromised,
				new ArgsList(IP.destination), FrameOfDiscernment.True));
		translationTables.add(new TranslationRow(SnipsPredicate.sendExploit,
				new ArgsList(IP.any, IP.destination), FrameOfDiscernment.theta,
				SnipsPredicate.compromised, new ArgsList(IP.destination),
				FrameOfDiscernment.theta));

	
	}
}
