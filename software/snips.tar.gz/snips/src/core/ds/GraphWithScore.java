// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import core.graph.Graph;

public class GraphWithScore implements Comparable<GraphWithScore> {

	private Graph graph;
	private Double score;

	public GraphWithScore(Graph t1, double t2) {
		this.graph = t1;
		this.score = t2;
	}

	@Override
	public int compareTo(GraphWithScore o) {
		int lastCmp = score.compareTo(o.score);
		return (lastCmp != 0 ? lastCmp : score.compareTo(o.score));
	}

	public Graph getGraph() {
		return graph;
	}

	public double getScore() {
		return score;
	}

	public void setGraph(Graph graph) {
		this.graph = graph;
	}

	public void setScore(double score) {
		this.score = score;
	}

}
