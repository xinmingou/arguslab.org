// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University


package core.ds;

public enum FrameOfDiscernment {
	True, False, theta, succeed, failed, inc,

	divTheta1; 
}
