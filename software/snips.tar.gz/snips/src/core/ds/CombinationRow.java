// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;

import core.graph.Fact;



public class CombinationRow {

	private FrameOfDiscernment frameElement1, frameElement2;
	private Fact fact1, fact2;
	private Double value1, value2, resultValue;
	private ArrayList<String> ruleId1, ruleId2;
	private FrameOfDiscernment resultFrameElement;

	public CombinationRow(Fact fact1, FrameOfDiscernment frameElement,
			ArrayList<String> ruleId1, Double value1, Fact fact2,
			FrameOfDiscernment goalFrameElement, ArrayList<String> ruleId2,
			Double value2, FrameOfDiscernment resultElement, Double result) {

		this.fact1 = fact1;
		this.frameElement1 = frameElement;
		this.setFact2(fact2);
		this.frameElement2 = goalFrameElement;
		this.resultValue = result;
		this.ruleId1 = ruleId1;
		this.ruleId2 = ruleId2;
		this.value1 = value1;
		this.value2 = value2;
		this.setResultFrameElement(resultElement);
	}

	public Fact getFact1() {
		return fact1;
	}

	public Fact getFact2() {
		return fact2;
	}

	public Double getResultValue() {
		return resultValue;
	}

	public void setFact1(Fact fact1) {
		this.fact1 = fact1;
	}

	public void setFact2(Fact fact2) {
		this.fact2 = fact2;
	}

	public void setResultValue(Double result) {
		this.resultValue = result;
	}

	@Override
	public String toString() {
		return "CombinationRow [frameElement=" + frameElement1
				+ ", goalFrameElement=" + frameElement2 + ", fact1=" + fact1
				+ ", fact2=" + fact2 + ", result=" + resultValue + "]";
	}

	public ArrayList<String> getRuleId1() {
		return ruleId1;
	}

	public void setRuleId1(ArrayList<String> ruleId1) {
		this.ruleId1 = ruleId1;
	}

	public ArrayList<String> getRuleId2() {
		return ruleId2;
	}

	public void setRuleId2(ArrayList<String> ruleId2) {
		this.ruleId2 = ruleId2;
	}

	public void setValue2(Double value2) {
		this.value2 = value2;
	}

	public Double getValue2() {
		return value2;
	}

	public void setValue1(Double value1) {
		this.value1 = value1;
	}

	public Double getValue1() {
		return value1;
	}

	public FrameOfDiscernment getFrameElement1() {
		return frameElement1;
	}

	public void setFrameElement1(FrameOfDiscernment frameElement1) {
		this.frameElement1 = frameElement1;
	}

	public FrameOfDiscernment getFrameElement2() {
		return frameElement2;
	}

	public void setFrameElement2(FrameOfDiscernment frameElement2) {
		this.frameElement2 = frameElement2;
	}

	public void setResultFrameElement(FrameOfDiscernment resultFrameElement) {
		this.resultFrameElement = resultFrameElement;
	}

	public FrameOfDiscernment getResultFrameElement() {
		return resultFrameElement;
	}

}
