
package core.ds;

import java.util.HashMap;

public final class RuleIdsGroups {
	public static HashMap<String, String> hash;

	public RuleIdsGroups() {
		hash = new HashMap<String, String>();
		// ///////////////////////////////////////////////////////////////////////////////
		hash.put("1:2021", "NFS");
		hash.put("1:2022", "NFS");
		hash.put("1:574", "NFS");
	}

}
