// This class is the implementation for the Dempster Shafer Theory on Snips,the output of this class is ranking for the compromised machines.
// usage new Ds(SnipsGraph object).rankGraphs(FrameOfDiscernment.True); or Theta. 
// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

import core.graph.Arcs;
import core.graph.Graph;
import core.graph.Internal;
import core.graph.Skolem;
import core.graph.SnipsGraph;
import core.graph.SnipsNode;
import core.utils.Utilities;


/**
 * @author lzomlot
 * 
 */

public class DS {

	protected  SnipsGraph input_graph;
	public  DsStuff ds_stuff_array[];
	public  Queue<SnipsNode> ds_processing_queue;
	private ArrayList<Pair<Graph, HashMap<FrameOfDiscernment, Double>>> graphWithBpaTableList;
	private ArrayList<GraphWithScore> graphWithScoreList;
	public static RuleIdsGroups ruleIdsGroups;
	public static HashMap<String, Double> ruleWeights;
	private boolean dsStandOrOur;

	public DS(SnipsGraph snipsgraph, boolean dsStandOrOur) {
		this.input_graph = snipsgraph;
		this.graphWithBpaTableList = new ArrayList<Pair<Graph, HashMap<FrameOfDiscernment, Double>>>();
		this.initializeds_stuff_array();
		this.ds_processing_queue = new LinkedList<SnipsNode>();
		DS.ruleIdsGroups = new RuleIdsGroups();
		DS.ruleWeights = new HashMap<String, Double>();
		this.dsStandOrOur = dsStandOrOur;
	}

	public void computeBpaTables() {
		for (Graph graph : this.input_graph.snipsgraph) {
			HashMap<FrameOfDiscernment, Double> resultBpaTable = computeOneGraph(graph);
			this.graphWithBpaTableList
					.add(new Pair<Graph, HashMap<FrameOfDiscernment, Double>>(
							graph, resultBpaTable));
		}
	}

	/**
	 * get all the rules that we have in this graph segment and put them in hash
	 * table according with their weights in double format.
	 * 
	 * @param graph
	 */
	private void hashRulesWeights(Graph graph) {
		for (SnipsNode node : graph.nodes) {
			if (node instanceof Skolem) {
				String rule = Utilities.getRuleId((Skolem) node);
				double weight = Utilities
						.convertMode(((Skolem) node).getMode());
				DS.ruleWeights.put(rule, weight);
				if (RuleIdsGroups.hash.containsKey(rule.trim())) {
					DS.ruleWeights.put(RuleIdsGroups.hash.get(rule.trim()),
							weight);
				}
				// }
			}
		}
	}

	public HashMap<FrameOfDiscernment, Double> computeOneGraph(Graph graph) {
		SnipsNode node = null;
		this.computePredcounter(graph);
		this.hashRulesWeights(graph);
		this.addSkolemsToQueue(graph);
		while (!this.ds_processing_queue.isEmpty()) {
			node = this.ds_processing_queue.element();
			// build the current node table
			this.computeBpaTable(node);
			// decrease all the outgoing nodes predCount by 1
			this.decreasePredCount(node);
			// mark visited and dequeue
			this.markVistedAndDequeue(node);
			// add the new nodes to the queue
			this.addZeroPredNotVisitedElementsToQueue(node);
		}
		// return the last dequeued node (the root)
		return ds_stuff_array[node.nodeNum].getBpaTable();
	}

	private void addZeroPredNotVisitedElementsToQueue(SnipsNode node) {
		for (Arcs arc : node.outGoing) {
			if (this.ds_stuff_array[arc.to.nodeNum].isPredCountZeroNotVisited()) {
				this.ds_processing_queue.add(arc.to);
			}
		}
	}

	private void markVistedAndDequeue(SnipsNode node) {
		this.ds_stuff_array[node.nodeNum].visted();
		this.ds_processing_queue.remove(node);
	}

	/**
	 * decrease all the outgoing nodes predCount by 1
	 * 
	 * @param snipsNode
	 */
	private void decreasePredCount(SnipsNode node) {
		for (Arcs arc : node.outGoing) {
			this.ds_stuff_array[arc.to.nodeNum].decreasePredCount();
		}
	}

	private void addSkolemsToQueue(Graph graph) {
		for (SnipsNode node : graph.nodes) {
			if (node instanceof Skolem) {
				this.ds_processing_queue.add(node);
			}
		}
	}

	/**
	 * Compute the predecessor counter in the ds_stuff_array
	 * 
	 * @param graph
	 */
	private void computePredcounter(Graph graph) {
		for (SnipsNode node : graph.nodes) {
			this.ds_stuff_array[node.nodeNum].setPredCount(node.inComing.size());
		}

	}

	public ArrayList<Pair<Graph, HashMap<FrameOfDiscernment, Double>>> getFinalResult() {
		return graphWithBpaTableList;
	}

	public ArrayList<GraphWithScore> getGraphWithScoreList() {
		return graphWithScoreList;
	}

	/**
	 * This is the main method for the DS class
	 * 
	 * @return ArrayList of Graphs with scores
	 */
	public ArrayList<GraphWithScore> rankGraphs(FrameOfDiscernment element) {
		this.computeBpaTables();
		this.graphWithScoreList = createGraphWithScoreList(element);
		Comparator<GraphWithScore> comparator = Collections.reverseOrder();
		Collections.sort(this.graphWithScoreList, comparator);

		return this.graphWithScoreList;
	}

	public void setGraphWithScoreList(
			ArrayList<GraphWithScore> graphWithScoreList) {
		this.graphWithScoreList = graphWithScoreList;
	}

	private DsStuff buildBpaTableFromSkolem(Skolem currentNode) {
		DsStuff skolemStuff = new DsStuff();
		double skolemWeight = Utilities.convertMode(currentNode.mode);
		Internal leafIntNode = (Internal) currentNode.outGoing.get(0).to;
		skolemStuff.setFact(leafIntNode.fact);
		// get the rule id from nodes and put them in groups
		skolemStuff.setRuleId(Utilities.preprocessRuleIdSet(Utilities
				.getRuleId(currentNode)));
		skolemStuff.getBpaTable().put(FrameOfDiscernment.True, skolemWeight);
		skolemStuff.getBpaTable().put(FrameOfDiscernment.theta,
				1.0 - skolemWeight);
		this.ds_stuff_array[currentNode.nodeNum] = skolemStuff;
		return skolemStuff;
	}

	private void computeBpaTable(SnipsNode node) {
		if (node instanceof Skolem) {
			this.buildBpaTableFromSkolem((Skolem) node);
		} else if (node instanceof Internal) {
			if (node.inComing.size() > 1) {// To combine
				this.ds_stuff_array=new Combination(node,this.ds_stuff_array,this.dsStandOrOur).combine();
			} else { // To translation
				this.ds_stuff_array=new Translation(this.ds_stuff_array).translate(node);
			}
		}
	}

	private ArrayList<GraphWithScore> createGraphWithScoreList(
			FrameOfDiscernment element) {
		ArrayList<GraphWithScore> graphWithScoreList = new ArrayList<GraphWithScore>();
		for (Pair<Graph, HashMap<FrameOfDiscernment, Double>> pair : this.graphWithBpaTableList) {
			if (!pair.second.isEmpty()) {

				if (element == FrameOfDiscernment.True) {
					graphWithScoreList.add(new GraphWithScore(pair.first,
							pair.second.get(element)));

				} else {
					graphWithScoreList.add(new GraphWithScore(pair.first,
							pair.second.get(element)));
				}

			} else {
				graphWithScoreList.add(new GraphWithScore(pair.first, -1));
			}

		}
		return graphWithScoreList;
	}

	private Pair<Integer, Integer> howManyNodesAndPredInit() {
		int size = 0, predCountInitValue = 0;
		for (Graph graph : input_graph.snipsgraph) {
			for (SnipsNode node : graph.nodes) {
				if (size < node.nodeNum) {
					size = node.nodeNum;
				}
				
				if (predCountInitValue < node.inComing.size()) {
					predCountInitValue = node.inComing.size();
				}
			}
		}
		return new Pair<Integer, Integer>(size, predCountInitValue);
	}

	private void initializeds_stuff_array() {
		Pair<Integer, Integer> temp = this.howManyNodesAndPredInit();
		ds_stuff_array = new DsStuff[temp.first + 1];
		for (int i = 0; i < ds_stuff_array.length; i++) {
			ds_stuff_array[i] = new DsStuff(temp.second);
		}
	}

}
