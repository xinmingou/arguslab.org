// main combination class
// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.ds;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

import core.graph.Arcs;
import core.graph.Internal;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.utils.Utilities;


public class Combination extends Translation {

	private ArrayList<CombinationRow> combinationTable;
	private Internal combinedNode;
	private DsStuff combinedTable;
	private Comparator<DsStuff> comparator;
	private PriorityQueue<DsStuff> children_processing_queue;
	public  DsStuff ds_stuff_array[];
	private boolean dsStandOrOur;

	public Combination(SnipsNode node, DsStuff[] ds_stuff_array, boolean dsStandOrOur) {
		super(ds_stuff_array);
		this.combinationTable = new ArrayList<CombinationRow>();
		this.combinedNode = (Internal) node;
		this.comparator = new QueueSorter();
		this.children_processing_queue = new PriorityQueue<DsStuff>(
				this.combinedNode.inComing.size(), comparator);
		this.ds_stuff_array=ds_stuff_array;
		this.dsStandOrOur=dsStandOrOur;
	}

	protected DsStuff[] combine() {
		// put all the children in one arraylist childrenNodes
		this.fillChildrenNodes();

		// combine children recursively
		this.combineRecursive(this.children_processing_queue.remove(),
				this.children_processing_queue.remove());

		// put fact
		this.combinedTable.setFact(this.combinedNode.fact);

		// put the final value in the main array
		this.ds_stuff_array[this.combinedNode.nodeNum] = this.combinedTable;
		return this.ds_stuff_array;
	}

	private void combineRecursive(DsStuff currentNode, DsStuff nextNode) {
		// recursive case
		DsStuff currentCombinedNode = new DsStuff();
		this.combinationTable = new ArrayList<CombinationRow>();
		this.buildCombinationTable(currentNode, nextNode);
		currentCombinedNode.setBpaTable(this.buildBpaTable());
		currentCombinedNode.setRuleId(unionRuleIds(currentNode.getRuleId(),
				nextNode.getRuleId()));

		// base case
		if (!this.children_processing_queue.isEmpty()) {
			this.children_processing_queue.add(currentCombinedNode);
			// this.sortDescending();
			this.combineRecursive(this.children_processing_queue.remove(),
					this.children_processing_queue.remove());
		} else {
			this.combinedTable = currentCombinedNode;
		}
	}

	private HashMap<FrameOfDiscernment, Double> buildBpaTable() {
		HashMap<FrameOfDiscernment, Double> bpaTable = new HashMap<FrameOfDiscernment, Double>();
		// if the table has the same value
		for (CombinationRow row : this.combinationTable) {
			if (bpaTable.containsKey(row.getResultFrameElement())) {
				double tableValue = bpaTable.get(row.getResultFrameElement());
				double acumulatedValue = tableValue + row.getResultValue();
				bpaTable.put(row.getResultFrameElement(), acumulatedValue);
			} else {// create new field in the table
				bpaTable.put(row.getResultFrameElement(), row.getResultValue());
			}
		}

		return bpaTable;
	}

	private ArrayList<String> unionRuleIds(ArrayList<String> ruleId1,
			ArrayList<String> ruleId2) {
		ArrayList<String> ruleId = new ArrayList<String>();
		ArrayList<String> tempRuleId = new ArrayList<String>();
		tempRuleId.addAll(ruleId1);
		tempRuleId.addAll(ruleId2);
		for (String r : tempRuleId) {
			if (!ruleId.contains(r.trim())) {
				ruleId.add(r.trim());
			}

		}

		return ruleId;
	}

	private void buildCombinationTable(DsStuff firstNode, DsStuff secondNode) {
		HashMap<FrameOfDiscernment, Double> firstBpaTable = firstNode
				.getBpaTable();
		HashMap<FrameOfDiscernment, Double> secondBpaTable = secondNode
				.getBpaTable();
		double w1 = 1 - firstBpaTable.get(FrameOfDiscernment.theta);
		double w2 = 1 - secondBpaTable.get(FrameOfDiscernment.theta);

		// get r1 and r2 using w1,w2 of true
		Pair<Double, Double> r1r2 = computeR(firstNode.getRuleId(), secondNode
				.getRuleId(), w1, w2);
		double r1;
		double r2;
		if (this.dsStandOrOur) {
			r1 = 0;
			r2 = 0;
		} else {
			r1 = r1r2.first;
			r2 = r1r2.second;
		}
		double cell = 0;
		double w1Prime = 1 - w1;
		double w2Prime = 1 - w2;

		// *******************************
		// True,True
		if (w2 <= w1) {
			cell = r2 * w2 + (1 - r2) * w1 * w2;
		} else {
			cell = r1 * w1 + (1 - r1) * w1 * w2;
		}
		this.combinationTable.add(new CombinationRow(firstNode.getFact(),
				FrameOfDiscernment.True, firstNode.getRuleId(), w1, secondNode
						.getFact(), FrameOfDiscernment.True, secondNode
						.getRuleId(), w2, FrameOfDiscernment.True, cell));

		// *******************************
		// True,Theta
		cell = (1 - r1) * w1 * w2Prime;
		this.combinationTable.add(new CombinationRow(firstNode.getFact(),
				FrameOfDiscernment.True, firstNode.getRuleId(), w1, secondNode
						.getFact(), FrameOfDiscernment.theta, secondNode
						.getRuleId(), w2Prime, FrameOfDiscernment.True, cell));

		// *******************************
		// Theta,True
		cell = (1 - r2) * w1Prime * w2;
		this.combinationTable.add(new CombinationRow(firstNode.getFact(),
				FrameOfDiscernment.theta, firstNode.getRuleId(), w1Prime,
				secondNode.getFact(), FrameOfDiscernment.True, secondNode
						.getRuleId(), w2, FrameOfDiscernment.True, cell));

		// *******************************
		// Theta,Theta

		if (w2Prime <= w1Prime) {
			cell = r1 * w2Prime + (1 - r1) * w1Prime * w2Prime;
		} else {
			cell = r2 * w1Prime + (1 - r2) * w1Prime * w2Prime;
		}
		this.combinationTable.add(new CombinationRow(firstNode.getFact(),
				FrameOfDiscernment.theta, firstNode.getRuleId(), w1Prime,
				secondNode.getFact(), FrameOfDiscernment.theta, secondNode
						.getRuleId(), w2Prime, FrameOfDiscernment.theta, cell));

	}

	private Pair<Double, Double> computeR(ArrayList<String> ruleId1,
			ArrayList<String> ruleId2, double w1, double w2) {
		double r1 = 0, r2 = 0;
		double factor = 0;
		double w1RulesWeighs = 0;
		double w2RulesWeighs = 0;
		double overlappingWeight = 0;
		// calculate w1 and w2 weights of rules and calculate the weight of
		// overlapping
		for (String id1 : ruleId1) {
			for (String id2 : ruleId2) {
				if (id1.trim().equalsIgnoreCase(id2.trim())) {
					overlappingWeight += this.getRuleWeight(id1);
				}
			}
		}
		for (String id1 : ruleId1) {
			w1RulesWeighs += this.getRuleWeight(id1);
		}
		for (String id2 : ruleId2) {
			w2RulesWeighs += this.getRuleWeight(id2);
		}

		// choose what to estimate first r1 or r2
		factor = (w1 / w2) * ((1 - w2) / (1 - w1));
		if (factor <= 1) {
			r1 = overlappingWeight / w1RulesWeighs;
			r2 = r1 * factor;
		} else {
			r2 = overlappingWeight / w2RulesWeighs;
			r1 = r2 * (1 / factor);
		}

		return new Pair<Double, Double>(r1, r2);
	}

	private double getRuleWeight(String id1) {
		String rule = id1.trim();
		if (DS.ruleWeights.containsKey(rule)) {
			return DS.ruleWeights.get(rule);
		} else {
			Utilities.print("error");
		}
		return 0;
	}

	private void fillChildrenNodes() {

		// build skolem Tables for all skolems in this node if any
		for (Arcs arc : this.combinedNode.inComing) {
			SnipsNode curretnNode = arc.from;

			if (curretnNode instanceof Skolem) {// Skolem nodes already done
				this.children_processing_queue
						.add(this.ds_stuff_array[curretnNode.nodeNum]);

			} else {// if node is Internal. Translate each node to root and put
					// it in the array List
					// if node predicate not as the root predicate

				if (!((Internal) curretnNode).fact.predicate.trim()
						.equalsIgnoreCase(
								this.combinedNode.fact.predicate.trim())) {
					this.children_processing_queue.add(this
							.translateToCombined(curretnNode));
				} else {
					this.children_processing_queue
							.add(this.ds_stuff_array[curretnNode.nodeNum]);
				}
			}
		}

	}

	/**
	 * for translation purposes
	 * 
	 * @param node
	 * @return
	 */
	private DsStuff translateToCombined(SnipsNode node) {
		Internal sourceNode = (Internal) node;
		Internal currentNode = this.combinedNode;
		DsStuff currentDsStuff = new DsStuff();

		// translate from table
		HashMap<FrameOfDiscernment, Double> sourceBpaTable = this.ds_stuff_array[sourceNode.nodeNum]
				.getBpaTable();
		for (FrameOfDiscernment sourceElement : sourceBpaTable.keySet()) {
			if (sourceNode.fact.predicate.trim().equalsIgnoreCase(
					"sendExploit")
					&& sourceElement == FrameOfDiscernment.True) {
				currentDsStuff = this.splitTrueToSuccFailed(
						sourceNode, currentNode, sourceBpaTable,
						sourceElement, currentDsStuff);
			} else {
				TranslationRow tempRow = buildTranslationRow(sourceNode,
						currentNode, sourceElement, sourceBpaTable
								.get(sourceElement));
				tempRow = lookupTranslationTable(tempRow);
				currentDsStuff = addToDsStuffArray(tempRow, currentDsStuff);
			}
		}
		currentDsStuff.setFact(this.combinedNode.fact);
		currentDsStuff.setRuleId(this.ds_stuff_array[sourceNode.nodeNum]
				.getRuleId());
		return currentDsStuff;

	}

	private DsStuff addToDsStuffArray(TranslationRow tempRow,
			DsStuff currentDsStuff) {
		// if the table has the same value
		if (currentDsStuff.getBpaTable().containsKey(
				tempRow.getGoalFrameElement())) {
			double tableValue = currentDsStuff.getBpaTable().get(
					tempRow.getGoalFrameElement());
			double acumulatedValue = tableValue + tempRow.getGoalBpaValue();
			currentDsStuff.getBpaTable().put(tempRow.getGoalFrameElement(),
					acumulatedValue);
		} else {
			// create new field in the table
			currentDsStuff.getBpaTable().put(tempRow.getGoalFrameElement(),
					tempRow.getGoalBpaValue());
		}
		return currentDsStuff;
	}

	private DsStuff splitTrueToSuccFailed(Internal sourceNode,
			Internal currentNode,
			HashMap<FrameOfDiscernment, Double> sourceBpaTable,
			FrameOfDiscernment sourceElement, DsStuff currentDsStuff) {

		TranslationRow tempRow;
		double succValue = sourceBpaTable.get(sourceElement) * 0.6;
		double failValue = sourceBpaTable.get(sourceElement) * 0.4;
		tempRow = buildTranslationRow(sourceNode, currentNode,
				FrameOfDiscernment.succeed, succValue);
		tempRow = lookupTranslationTable(tempRow);
		currentDsStuff = this.addToDsStuffArray(tempRow, currentDsStuff);
		tempRow = buildTranslationRow(sourceNode, currentNode,
				FrameOfDiscernment.failed, failValue);
		tempRow = lookupTranslationTable(tempRow);
		currentDsStuff = this.addToDsStuffArray(tempRow, currentDsStuff);
		return currentDsStuff;
	}

}
