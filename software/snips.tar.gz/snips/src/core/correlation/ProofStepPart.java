
package core.correlation;

public class ProofStepPart {

}
