// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.util.ArrayList;
import java.util.Hashtable;

public class FactMap {
	public  Hashtable<Integer, Dset> factMap = new Hashtable<Integer, Dset>();
	public  ArrayList<ProofStep> proofSteps = new ArrayList<ProofStep>();
	public static int dhashcode = 0;

	public FactMap(ArrayList<ProofStep> proofSteps) {
		this.proofSteps=proofSteps;
	}

	public  void fillFactMap() {
		for (final ProofStep proofStep : this.proofSteps) {
			Dset dSet;
			// create DB object
			final InternalProofStepPart intRPart = proofStep
					.getRightPart();
			final DB db = new DB(intRPart.getFact(), intRPart.getTimeRange(),
					proofStep.getRuleID(), proofStep.getDirection());
			final ProofStepPart LPart = proofStep.getLeftPart();

			if (LPart instanceof InternalProofStepPart) {
				final InternalProofStepPart intLPart = (InternalProofStepPart) LPart;
				final DA da = new DAFact(intLPart.getFact(), intLPart
						.getTimeRange(), proofStep.getRuleID(), proofStep
						.getDirection());
				da.setOutgoing(db);
				db.setIncoming(da);

				// left part
				final int leftfactHashCode = intLPart.getFact().hashCode();
				// if fact is not in hashtable
				if (!factMap.containsKey(leftfactHashCode)) {
					dSet = new Dset();
					// if in the hash table
				} else {
					dSet = factMap.get(leftfactHashCode);
				}
				dSet.getdSet().add(da);
				dSet.sortDset();
				factMap.put(leftfactHashCode, dSet);

			} else if (LPart instanceof SkolemProofStepPart) {
				final SkolemProofStepPart skolemLPart = (SkolemProofStepPart) LPart;
				final DA da = new DASkolem(skolemLPart.getId(), skolemLPart
						.getCId(), skolemLPart.getSId(), skolemLPart.getMode());
				da.setOutgoing(db);
				db.setIncoming(da);
			}

			// right part
			final int rightfactHashCode = intRPart.getFact().hashCode();
			// if fact is not in hashtable
			if (!factMap.containsKey(rightfactHashCode)) {
				dSet = new Dset();
				// if in the hash table
			} else {
				dSet = factMap.get(rightfactHashCode);
			}
			dSet.getdSet().add(db);
			dSet.sortDset();
			factMap.put(rightfactHashCode, dSet);
		}

	}

}
