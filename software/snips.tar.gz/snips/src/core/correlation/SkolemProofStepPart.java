// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import core.graph.Mode;

public class SkolemProofStepPart extends ProofStepPart {

	private String Id;
	private String Cid;
	private String Sid;
	private Mode mode;

	public SkolemProofStepPart(String id, String cid, String sid, Mode mode) {
		this.Id = id;
		this.Cid = cid;
		this.Sid = sid;
		this.mode = mode;
	}

	public SkolemProofStepPart() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return this.Id;
	}

	public Mode getMode() {

		return this.mode;
	}

	public String getSId() {

		return this.Sid;
	}

	public String getCId() {

		return this.Cid;
	}
}
