// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.util.ArrayList;
import java.util.Hashtable;

import core.ds.Pair;
import core.graph.Arcs;
import core.graph.Graph;
import core.graph.Internal;
import core.graph.Skolem;
import core.graph.SnipsNode;
import core.graph.TimeRange;


public class MergeDs {
	public  Hashtable<Integer, Dset> factMap = new Hashtable<Integer, Dset>();
	private Hashtable<Integer, ArrayList<Pair<D, SnipsNode>>> dNodeMap = new Hashtable<Integer, ArrayList<Pair<D, SnipsNode>>>();
	private int nodeNum=0;

	public MergeDs(Hashtable<Integer, Dset> factMap) {
		this.factMap=factMap;
	}

	private void merge() {

		for (Dset dSet : this.factMap.values()) {
			D[] dArray = dSet.toArray();
			if (dArray.length == 1) {
				this.updateDNodeMap(this.createNode(dArray[0],
						dArray[0].timeRange), dArray, 0, 0);
			} else {
				int jj = 0;
				int i = 0;
				for (; i < dArray.length; i++) {
					TimeRange time1 = dArray[i].timeRange;
					if (i == dArray.length - 1) {
						this.updateDNodeMap(this.createNode(dArray[i], time1),
								dArray, i, i);
						break;
					}
					for (int j = i + 1; j < dArray.length; j++) {
						TimeRange time2 = dArray[j].timeRange;
						// overlapping case
						if (TimeRange.isOverlapping(time1, time2)) {
							time1 = TimeRange.overlapping(time1, time2);
							// j at array end
							if (j == dArray.length - 1) {
								this.updateDNodeMap(this.createNode(dArray[i],
										time1), dArray, i, j);
								i = dArray.length;
								break;
							}
							// can not correlate any more case (no overlapping)
						} else {
							if (jj == 0 || jj < j) {
								this.updateDNodeMap(this.createNode(dArray[i],
										time1), dArray, i, j - 1);
								jj = j;
								break;
							} else if (jj - 1 == i) {
								if (j == dArray.length - 1) {
									this.updateDNodeMap(this.createNode(
											dArray[i], time1), dArray, j, j);
									i = dArray.length;
									break;
								}
								jj = 0;
								break;
							} else {
								break;
							}
						}
					}
				}
			}
		}
	}

	private void updateDNodeMap(SnipsNode node, D[] dArray, int startD, int endD) {

		for (int i = startD; i <= endD; i++) {
			if (dNodeMap.containsKey(dArray[i].hashCode())) {
				ArrayList<Pair<D, SnipsNode>> tmpArray = dNodeMap.get(dArray[i]
						.hashCode());
				tmpArray.add(new Pair<D, SnipsNode>(dArray[i], node));
				dNodeMap.put(dArray[i].hashCode(), tmpArray);
			} else {
				ArrayList<Pair<D, SnipsNode>> tmpArray = new ArrayList<Pair<D, SnipsNode>>();
				tmpArray.add(new Pair<D, SnipsNode>(dArray[i], node));
				dNodeMap.put(dArray[i].hashCode(), tmpArray);
			}
		}
	}

	private SnipsNode createNode(D d, TimeRange timeRange) {
		if (d instanceof DASkolem) {
			DASkolem dSkolem = (DASkolem) d;
			return new Skolem(nodeNum++, dSkolem.getId(), dSkolem.getSid(),dSkolem.getCid(), dSkolem.getMode());
		} else {
			return new Internal(nodeNum++, d.getFact(), timeRange);
		}
	}

	private void createArcs() {
		for (Integer key : dNodeMap.keySet()) {
			ArrayList<Pair<D, SnipsNode>> pairsArray = new ArrayList<Pair<D, SnipsNode>>();

			for (Pair<D, SnipsNode> pairDNode : dNodeMap.get(key)) {
				if (pairDNode.first instanceof DAFact) {
					pairsArray.add(fromDaArc(pairDNode));
				} else if (pairDNode.first instanceof DB) {
					pairsArray.add(toDbArc(pairDNode));
				}
			}
			dNodeMap.put(key, pairsArray);
		}
	}

	private Pair<D, SnipsNode> fromDaArc(Pair<D, SnipsNode> pairDNode) {
		DAFact currntD = (DAFact) pairDNode.first;
		ArrayList<Pair<D, SnipsNode>> outgoingPairArray = dNodeMap.get(currntD
				.getOutgoing().hashCode());
		if (outgoingPairArray == null) {
			Utilities.print(currntD.getOutgoing().hashcode + "*********");
			Utilities.print(pairDNode.second.nodeNum + "*********");
			return pairDNode;
		}
		Internal currNode = (Internal) pairDNode.second;
		ArrayList<Arcs> outgoingArcsArray = currNode.getOutGoing();

		for (Pair<D, SnipsNode> pair : outgoingPairArray) {
			Arcs arc = ArcsPool.getArc(new Arcs(currNode, pair.second, currntD
					.getRuleID()));

			if (!outgoingArcsArray.contains(arc)) {
				outgoingArcsArray.add(arc);
				currNode.setOutGoing(outgoingArcsArray);
				pairDNode.second = currNode;
			}
		}
		return pairDNode;
	}

	private Pair<D, SnipsNode> toDbArc(Pair<D, SnipsNode> pairDNode) {
		// because skolems not been merged we create them here
		if (((DB) pairDNode.first).getIncoming() instanceof DASkolem) {
			return dbArcDaSkolem(pairDNode);
		} else {
			return dbArcDaFact(pairDNode);
		}
	}

	private Pair<D, SnipsNode> dbArcDaFact(Pair<D, SnipsNode> pairDNode) {
		DB currentD = (DB) pairDNode.first;
		ArrayList<Pair<D, SnipsNode>> incomingPairArray = dNodeMap.get(currentD
				.getIncoming().hashCode());
		if (incomingPairArray == null) {
			return pairDNode;
		}
		Internal currNode = (Internal) pairDNode.second;
		ArrayList<Arcs> incomingArcsArray = currNode.getInComing();
		for (Pair<D, SnipsNode> pair : incomingPairArray) {
			Arcs arc = ArcsPool.getArc(new Arcs(pair.second, currNode, currentD
					.getRuleID()));

			if (!incomingArcsArray.contains(arc)) {
				incomingArcsArray.add(arc);
				currNode.setInComing(incomingArcsArray);
				pairDNode.second = currNode;
			}
		}
		return pairDNode;
	}

	private Pair<D, SnipsNode> dbArcDaSkolem(Pair<D, SnipsNode> pairDNode) {
		DB tmpDB = (DB) pairDNode.first;
		Internal tmpCurrNode = (Internal) pairDNode.second;
		SnipsNode incomingNode;
		DASkolem dSkolem = (DASkolem) tmpDB.getIncoming();
		incomingNode = this.createNode(dSkolem, null);
		ArrayList<Arcs> outgoingArray = incomingNode.getOutGoing();
		outgoingArray.add(ArcsPool.getArc(new Arcs(incomingNode, tmpCurrNode,
				tmpDB.getRuleID())));
		incomingNode.setOutGoing(outgoingArray);
		ArrayList<Arcs> incomingArray = tmpCurrNode.getInComing();
		Arcs arc = ArcsPool.getArc(new Arcs(incomingNode, tmpCurrNode, tmpDB
				.getRuleID()));
		// to handle multiple arcs between two nodes
		if (!incomingArray.contains(arc)) {
			incomingArray.add(arc);
			tmpCurrNode.setInComing(incomingArray);
			pairDNode.second = tmpCurrNode;
		}
		return pairDNode;
	}

	public Graph createSnipsGraph() {
		this.merge();
		this.createArcs();
		Hashtable<Integer, SnipsNode> tmpNodeHash = new Hashtable<Integer, SnipsNode>();
		for (ArrayList<Pair<D, SnipsNode>> pairArray : dNodeMap.values()) {
			for (Pair<D, SnipsNode> pair : pairArray) {
				for (Arcs arc : pair.second.getInComing()) {
					if (arc.from instanceof Skolem) {
						tmpNodeHash.put(arc.from.getNodeNum(), arc.from);
					}
				}
				tmpNodeHash.put(pair.second.getNodeNum(), pair.second);
			}
		}
		return new Graph(new ArrayList<SnipsNode>(tmpNodeHash.values()));
	}

	public int getNodeNum() {
		return nodeNum;
	}

	public void setNodeNum(int nodeNum) {
		this.nodeNum = nodeNum;
	}

}
