// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import core.graph.TimeRange;
import core.main.Snips3;


public class ConnectDB {
	private String summProofStepTable;
	private String intProofStepTable;
	private String dbName;
	private String userName;
	private String password;
	public  ArrayList<ProofStep> proofSteps = new ArrayList<ProofStep>();
	
	public ConnectDB(String summProofStepTable, String intProofStepTable,
			String dbName, String userName, String password) {
		this.summProofStepTable = summProofStepTable.trim();
		this.intProofStepTable = intProofStepTable.trim();
		this.dbName = dbName.trim();
		this.userName = userName.trim();
		this.password = password.trim();
	}

	public ArrayList<ProofStep> getProofSteps() {
		Connection conn = null;

		try {
			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName,
					this.password);

			getSummProofSteps(conn);
			getIntProofSteps(conn);

		} catch (Exception e) {
			System.err.println("Cannot connect to database server Coorelation");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
		return this.proofSteps;
	}

	private void getSummProofSteps(Connection conn) {
		try {
			Statement s = conn.createStatement();
			s.executeQuery("SELECT * FROM " + this.summProofStepTable);
			ResultSet rs = s.getResultSet();
			while (rs.next()) {
				// //summpstable:
				// skolem_id,snort_rule_id,mode,pred,h1,h2,start_time,end_time
				// //summclause:proofStep(skolem(ID, snort(SnortRuleID), Mode),
				// summarizedFact, int(Fact, Mode, Time), o)
				this.proofSteps
						.add(new ProofStep(
								new SkolemProofStepPart(rs
										.getString(1),
										Utilities.splitSnortRuleId(rs
												.getString(2)).first, Utilities
												.splitSnortRuleId(rs
														.getString(2)).second,
										Utilities.stringToMode(rs.getString(3))),
								"summarizedFact",
								new InternalProofStepPart(FactsPool.getFact(rs
										.getString(4), rs.getString(5), rs
										.getString(6)), Utilities
										.stringToMode(rs.getString(3)),
										new TimeRange(rs.getString(7), rs
												.getString(8))), "o"));
			}
			rs.close();
			s.close();

		} catch (SQLException e) {
			System.err.println("Error message: " + e.getMessage());
			System.err.println("Error number: " + e.getErrorCode());
		}

	}

	private void getIntProofSteps(Connection conn) {
		try {
			Statement s = conn.createStatement();
			s.executeQuery("SELECT * FROM " + this.intProofStepTable);
			ResultSet rs = s.getResultSet();
			while (rs.next()) {
				// intpstable:
				// left_pred,left_h1,left_h2,left_mode,left_start_time,left_end_time,rule_Id,right_pred,right_h1,right_h2,right_mode,right_start_time,right_end_time,diraction
				// intpsclause: proofStep(int(LeftFact, Mode1, LeftTime),
				// RuleId, int(RightFact, Mode, RightTime), Direction)

				this.proofSteps.add(new ProofStep(
				new InternalProofStepPart(FactsPool
								.getFact(rs.getString(1), rs.getString(2), rs
										.getString(3)), Utilities
								.stringToMode(rs.getString(4)), new TimeRange(
								rs.getString(5), rs.getString(6))),

						// IntruleIde
						rs.getString(7),

						// right
						new InternalProofStepPart(FactsPool.getFact(rs
								.getString(8), rs.getString(9), rs
								.getString(10)), Utilities.stringToMode(rs
								.getString(11)), new TimeRange(
								rs.getString(12), rs.getString(13))),

						// direction
						rs.getString(14)));
			}
			rs.close();
			s.close();

		} catch (SQLException e) {
			System.err.println("Error message: " + e.getMessage());
			System.err.println("Error number: " + e.getErrorCode());
		}

	}

	public String getSummProofStepTable() {
		return summProofStepTable;
	}

	public void setSummProofStepTable(String summProofStepTable) {
		this.summProofStepTable = summProofStepTable;
	}

	public String getIntProofStepTable() {
		return intProofStepTable;
	}

	public void setIntProofStepTable(String intProofStepTable) {
		this.intProofStepTable = intProofStepTable;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
