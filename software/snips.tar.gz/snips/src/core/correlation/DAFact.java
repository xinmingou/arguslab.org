package core.correlation;

import core.graph.Fact;
import core.graph.TimeRange;

public class DAFact extends DA {

	public DAFact(Fact fact, TimeRange timeRange, String ruleID,
			String direction) {
		super(fact, timeRange, ruleID, direction);
	}

}
