// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import core.graph.Fact;
import core.graph.TimeRange;

//This Data structure for processing the parts of proofsteps, and apply correlation algorithm
public class D implements Comparable<D> {
	protected Fact fact;
	protected TimeRange timeRange;
	protected String ruleID;
	protected String direction;
	protected int hashcode;

	public D(Fact fact, TimeRange timeRange, String ruleID, String direction) {
		this.fact = fact;
		this.timeRange = timeRange;
		this.ruleID = ruleID;
		this.direction = direction;
		this.hashcode = FactMap.dhashcode++;

	}

	public D() {
	}

	public Fact getFact() {
		return fact;
	}

	public void setFact(Fact fact) {
		this.fact = fact;
	}

	public TimeRange getTimeRange() {
		return timeRange;
	}

	public void setTimeRange(TimeRange timeRange) {
		this.timeRange = timeRange;
	}

	public String getRuleID() {
		return ruleID;
	}

	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public int getHashcode() {
		return hashcode;
	}

	public void setHashcode(int hashcode) {
		this.hashcode = hashcode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + hashcode;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		D other = (D) obj;
		if (hashcode != other.hashcode) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "D [fact=" + fact + ", timeRange=" + timeRange + ", ruleID="
				+ ruleID + ", direction=" + direction + ", hashcode="
				+ hashcode + "]";
	}

	@Override
	public int compareTo(D o) {
		int endTimeCmp = timeRange.endTime.compareTo(o.getTimeRange().endTime);
		return (endTimeCmp != 0 ? endTimeCmp : timeRange.startTime.compareTo(o
				.getTimeRange().startTime));
	}

}
