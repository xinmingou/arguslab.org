// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import core.ds.Pair;
import core.graph.Mode;

public class Utilities {

	public static Pair<String, String> splitSnortRuleId(String string) {
		Pair<String, String> tmp = new Pair<String, String>();
		String[] cidSid = string.split(":");
		tmp.first = cidSid[0];
		tmp.second = cidSid[1];
		return tmp;
	}

	public static Mode stringToMode(String mode) {

		if (mode.trim().equalsIgnoreCase("u")) {
			return Mode.u;
		} else if (mode.trim().equalsIgnoreCase("p")) {
			return Mode.p;
		} else if (mode.trim().equalsIgnoreCase("l")) {
			return Mode.l;
		} else if (mode.trim().equalsIgnoreCase("c")) {
			return Mode.c;
		} else {
			System.out.println("Mode string problem");
			return Mode.u;
		}
	}

	public static void print(Object stuff) {
		System.out.println(stuff);
	}

}
