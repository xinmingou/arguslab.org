// Author(s) : Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.util.ArrayList;

import core.graph.Graph;
import core.main.Snips3;


public class CorrelationGraph {
	public ArrayList<ProofStep> proofSteps = new ArrayList<ProofStep>();
	public FactMap factMap;
	public MergeDs mergeDs;
	
	public Graph createGraph(String summProofStepTable,
			String intProofStepTable, String dbName, String dbUserName,
			String dbPassword) {
		
		// get proofsteps from Database
		this.proofSteps=new ConnectDB(summProofStepTable, intProofStepTable, dbName,
				dbUserName, dbPassword).getProofSteps();

		// process proofsteps into fact Map
		this.factMap=new FactMap(this.proofSteps);
		this.factMap.fillFactMap();

		// merging facts and create graph
		this.mergeDs=new MergeDs(this.factMap.factMap);
		Graph resultGraph=this.mergeDs.createSnipsGraph();
		
		//update the global node num
		Snips3.currentGraphsNodeNumber+=this.mergeDs.getNodeNum();
		
		return resultGraph;

	}

}