// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import core.graph.Fact;
import core.graph.Mode;
import core.graph.TimeRange;

public class InternalProofStepPart extends ProofStepPart {
	private Fact fact;
	private Mode mode;
	private TimeRange timeRange;

	public InternalProofStepPart(Fact fact, Mode mode, TimeRange timeRange) {
		this.fact = fact;
		this.mode = mode;
		this.timeRange = timeRange;
	}

	public InternalProofStepPart() {
		// TODO Auto-generated constructor stub
	}

	public Fact getFact() {
		return fact;
	}

	public String getPredicate() {

		return fact.getPredicate();
	}

	public Mode getMode() {

		return mode;
	}

	public TimeRange getTimeRange() {
		return timeRange;
	}

	public void setTimeRange(TimeRange timeRange) {
		this.timeRange = timeRange;
	}

	public void setFact(Fact fact) {
		this.fact = fact;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
	}

}
