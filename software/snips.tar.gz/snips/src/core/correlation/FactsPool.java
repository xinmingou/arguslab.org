// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.util.Hashtable;

import core.graph.Fact;


public class FactsPool {
	private static Hashtable<String, Fact> factPool = new Hashtable<String, Fact>();

	public static Fact getFact(String pred, String arg1, String arg2) {
		String key = computeKey(pred, arg1, arg2);
		if (!key.trim().isEmpty()) {
			if (factPool.containsKey(key)) {
				return factPool.get(key);
			} else {
				Fact tmpFact = new Fact(pred, arg1, arg2);
				factPool.put(key, tmpFact);
				return tmpFact;
			}
		} else {
			System.out.println("Error in fact pool!");
			return new Fact();
		}
	}

	private static String computeKey(String pred, String arg1, String arg2) {
		return pred.trim().concat(arg1.trim()).concat(arg2.trim());
	}

	public static Hashtable<String, Fact> getFactPool() {
		return factPool;
	}

}
