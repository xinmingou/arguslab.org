// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.correlation;

import java.util.ArrayList;
import java.util.Collections;

//fill DPriority queue
public class Dset {
	private ArrayList<D> dSet = new ArrayList<D>();

	public void setdSet(ArrayList<D> dSet) {
		this.dSet = dSet;
	}

	/**
	 * 
	 * @return sorted array list of D by end time
	 */

	public void sortDset() {
		Collections.sort(this.dSet);
	}

	public ArrayList<D> getdSet() {
		return dSet;
	}

	public D[] toArray() {
		return this.dSet.toArray(new D[0]);
	}

}
