// Author(s) : Loai Zomlot (lzomlot@ksu.edu)
// Copyright (C) 2011, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;

import core.ds.RuleIdsGroups;
import core.ds.SnipsPredicate;
import core.graph.Internal;
import core.graph.Mode;
import core.graph.Skolem;
import core.graph.SnipsNode;



public final class Utilities {

	public static String toTrinaryString(int x) {
		ArrayList<Integer> y = toTrinary(x);
		String result = new String();
		for (Integer i : y) {
			result = Integer.toString(i) + result;
		}
		return result;
	}

	private static ArrayList<Integer> toTrinary(int x) {
		ArrayList<Integer> y = new ArrayList<Integer>();
		if (x / 3 == 0 || x == 1) {
			y.add(x);
		} else {

			while (x != 2 && x != 1) {
				y.add(x % 3);
				x = x / 3;

			}
			if (x == 2) {
				y.add(2);
			} else {
				y.add(1);
			}

		}
		return y;
	}

	public static String getRuleId(Skolem skolem) {
		String ruleId = skolem.Sid + ":" + skolem.Cid;
		return ruleId;
	}

	public static double convertMode(Mode mode) {
		switch (mode) {
		case u:
			return 0.01;
		case p:
			return 0.1;
		case l:
			return 0.3;
		case c:
			return 0.5;
		default:
			System.out.println("error");
			break;
		}

		return 0;
	}

	public static SnipsPredicate convertToPredicate(String string) {
		if (string.trim().equalsIgnoreCase("probeOtherMachine"))
			return SnipsPredicate.probeOtherMachine;
		else if (string.trim().equalsIgnoreCase("compromised"))
			return SnipsPredicate.compromised;
		else if (string.trim().equalsIgnoreCase("sendExploit"))
			return SnipsPredicate.sendExploit;
		else
			return null;
	}

	public static Double mul(Double double1, Double double2) {
		if (double1 == null || double2 == null) {
			// System.out.println("whats up");
			return (double) 0;
		} else {
			return double1 * double2;
		}

	}

	public static void print(Object stuff) {
		System.out.println(stuff);
	}

	public static ArrayList<String> preprocessRuleIdSet(String ruleId) {
		HashMap<String, Boolean> result = new HashMap<String, Boolean>();
		String temp;
		temp = RuleIdsGroups.hash.get(ruleId);
		if (temp != null) {
			result.put(temp, true);
		} else {
			result.put(ruleId, true);
		}
		ArrayList<String> finalResult = new ArrayList<String>();
		for (String string : result.keySet()) {
			finalResult.add(string);
		}

		return finalResult;
	}


	public static boolean isSink(SnipsNode node) {
		if (node instanceof Internal & node.outGoing.isEmpty() & !node.inComing.isEmpty()) {
			return true;	
		}
		return false;
	}

	public static double roundDouble(double threshold,int scale) {
		BigDecimal bd = new BigDecimal(threshold);
		bd = bd.setScale(scale,BigDecimal.ROUND_HALF_UP);
		threshold=bd.doubleValue();
		return threshold;
	}
}
