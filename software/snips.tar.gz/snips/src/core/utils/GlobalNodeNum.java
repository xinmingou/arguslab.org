// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import core.main.Snips3;


public class GlobalNodeNum {
	private String dbName;
	private String userName;
	private String password;
	private String globalNodeNumTable;

	public GlobalNodeNum(String dbName, String userName, String password, String globalNodeNumTable) {
		this.dbName = dbName.trim();
		this.userName = userName.trim();
		this.password = password.trim();
		this.globalNodeNumTable=globalNodeNumTable.trim();
	}


	public void setGlobalNodeNum(int nodeNum){
		Connection conn = null;
		try {
			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName,this.password);
			Statement s = conn.createStatement();
			s.executeUpdate("update " + this.globalNodeNumTable + " set node_num= " + nodeNum);
			s.close();
		} catch (Exception e) {
			System.err.println("Cannot connect to database server globalNodeNum");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
	}

	public int getGlobalNodeNum(){
		int nodeNum=0;
		Connection conn = null;
		try {
			String url = Snips3.urlHeader + this.dbName;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, this.userName,this.password);
			ResultSet rs;
			Statement s = conn.createStatement();
			s.executeQuery("SELECT * FROM " + this.globalNodeNumTable);
			rs = s.getResultSet();
			if (!rs.first()) {
				s.executeUpdate("insert into " + this.globalNodeNumTable + " (node_num) values (0) ");
			}else{
				nodeNum=rs.getInt(1);
			}
			s.close();
		} catch (Exception e) {
			System.err.println("Cannot connect to database server in GlobalNodeNum");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) { /* ignore close errors */
				}
			}
		}
		return nodeNum;
	}





}
