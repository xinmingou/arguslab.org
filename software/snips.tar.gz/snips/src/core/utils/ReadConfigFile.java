// Author(s) : Loai Zomlot 
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;


public class ReadConfigFile{
	public static void getParam(String configFile){
		try{
			FileInputStream fstream = new FileInputStream(configFile);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			while ((strLine = br.readLine()) != null)
				if (strLine.contains("=")) {
					String[] line = strLine.split("=");
					if (line[0].equalsIgnoreCase("db_host")) {
						ConfigParam.dbHost=line[1];
					}else if (line[0].equalsIgnoreCase("db_name")) {
						ConfigParam.dbName=line[1];
					}else if (line[0].equalsIgnoreCase("db_user")) {
						ConfigParam.dbUserName=line[1];
					}else if (line[0].equalsIgnoreCase("db_pass")) {
						ConfigParam.dbPassword=line[1];
					}else if (line[0].equalsIgnoreCase("summary_table")) {
						ConfigParam.summaryTable=line[1];
					}else if (line[0].equalsIgnoreCase("skolem_map_table")) {
						ConfigParam.skolemMapTable=line[1];
					}else if (line[0].equalsIgnoreCase("graphs_nodes_table")) {
						ConfigParam.nodesTable=line[1];
					}else if (line[0].equalsIgnoreCase("graphs_arcs_table")) {
						ConfigParam.arcsTable=line[1];
					}else if (line[0].equalsIgnoreCase("global_num_table")) {
						ConfigParam.globalNodeNumTable=line[1];
					}else if (line[0].equalsIgnoreCase("summary_proof_step_table")) {
						ConfigParam.summProofStepTable=line[1];
					}else if (line[0].equalsIgnoreCase("internal_proof_step_table")) {
						ConfigParam.intProofStepTable=line[1];
					}else if (line[0].equalsIgnoreCase("alerts_table")) {
						ConfigParam.alertsTable=line[1];
					}else if (line[0].equalsIgnoreCase("output_dot_file")) {
						ConfigParam.outputFilePath=line[1];
					}
				}
			in.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
	}
	
}

