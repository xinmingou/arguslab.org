// Author(s) : Sathya Chandran Sundaramurthy
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.util.ArrayList;

public class Fact {
	public String predicate;
	public ArrayList<String> argsList;

	public Fact(String predicate, String source, String dest) {
		this.predicate = predicate;
		argsList = new ArrayList<String>();
		if (dest.trim().equalsIgnoreCase("null")) {
			argsList = new ArrayList<String>();
			argsList.add(source);
		} else {
			argsList.add(source);
			argsList.add(dest);
		}
	}

	public Fact() {
		// TODO Auto-generated constructor stub
	}

	public String getPredicate() {

		return predicate;
	}

	public ArrayList<String> getArgsList() {

		return argsList;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;

		result = prime * result
				+ ((argsList == null) ? 0 : argsList.hashCode());
		result = prime * result
				+ ((predicate == null) ? 0 : predicate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Fact other = (Fact) obj;
		if (argsList == null) {
			if (other.argsList != null) {
				return false;
			}
		} else if (!argsList.equals(other.argsList)) {
			return false;
		}
		if (predicate == null) {
			if (other.predicate != null) {
				return false;
			}
		} else if (!predicate.equals(other.predicate)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Fact [predicate=" + predicate + ", argsList=" + argsList + "]";
	}

}
