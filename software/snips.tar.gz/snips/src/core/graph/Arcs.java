// Author(s) : Sathya Chandran Sundaramurthy
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

public class Arcs {
	public SnipsNode from;
	public SnipsNode to;
	public String ruleID;

	public Arcs(SnipsNode from, SnipsNode to, String ruleID) {
		this.from = from;
		this.to = to;
		this.ruleID = ruleID;
	}

	public Arcs(SnipsNode to) {
		this.to = to;
	}

	public Arcs() {
		// default constructor
	}

	public Arcs(Arcs another) {
		if (another.from instanceof Skolem) {
			this.from = new Skolem((Skolem) another.from);	
		}else if (another.from instanceof Internal) {
			this.from=new Internal((Internal) another.from);
		}
		
		if (another.to instanceof Skolem) {
			this.to = new Skolem((Skolem) another.to);	
		}else if (another.to instanceof Internal) {
			this.to=new Internal((Internal) another.to);
		}
		
		this.ruleID = another.ruleID;
	}

	public SnipsNode getFromNode() {

		return from;
	}

	public SnipsNode getToNode() {

		return to;
	}

	public String getRuleId() {

		return ruleID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + ((ruleID == null) ? 0 : ruleID.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Arcs other = (Arcs) obj;
		if (from == null) {
			if (other.from != null) {
				return false;
			}
		} else if (!from.equals(other.from)) {
			return false;
		}
		if (ruleID == null) {
			if (other.ruleID != null) {
				return false;
			}
		} else if (!ruleID.equals(other.ruleID)) {
			return false;
		}
		if (to == null) {
			if (other.to != null) {
				return false;
			}
		} else if (!to.equals(other.to)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Arcs [from=" + from.toString() + ", to=" + to.toString()
				+ ", ruleID=" + ruleID + "]";
	}

}
