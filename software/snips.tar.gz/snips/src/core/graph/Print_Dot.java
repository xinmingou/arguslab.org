// Author(s) : Kui Luo
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Iterator;

import core.main.Snips3;


public class Print_Dot {

	protected BufferedWriter br;
	protected String label = "[label= ";
	protected int node_fontsize = 10;
	protected String fontname = "fontname=\"Times-Bold\"";
	protected String node_fontcolor_red = "fontcolor=red];";
	protected String node_fontcolor_blue = "fontcolor=blue];";
	protected String root_node_fontcolor = "fontcolor=darkgreen];";
	protected String edge_fontcolor = "fontcolor=blue];";
	protected int edge_fontsize = 10;
	protected String node_step = "nodesep=1";
	protected int rank_step = 2;
	protected String open = "digraph snips {";
	protected String close = "}";
	protected String tab = "\t";
	protected String Node_lable;
	protected String toNode;
	

	void set(int size, int rank) {
		node_fontsize = size;
		edge_fontsize = size;
		rank_step = rank;
	}

	public void printToGraphVizFormat(SnipsGraph s, String table, String db,
			String outputFile) {
		if (outputFile == null) {
			outputFile = "snips_graph.dot";
			// System.out.println("Hello");
		} else {
			if (!outputFile.endsWith(".dot")) {
				outputFile = outputFile.concat(".dot");
			}

			// System.out.println(outputFile);
		}

		try {
			br = new BufferedWriter(new FileWriter(outputFile));
			br.write(open);
			br.newLine();
			Iterator<Graph> it1 = s.snipsgraph.iterator();
			Iterator<Graph> it2 = s.snipsgraph.iterator();
			while (it1.hasNext()) {
				Iterator<SnipsNode> no = it1.next().nodes.iterator();
				while (no.hasNext())
					print_node(no.next(), table, db);
			}
			while (it2.hasNext()) {
				Iterator<SnipsNode> ar = it2.next().nodes.iterator();
				while (ar.hasNext())
					print_arc(ar.next());
			}
			br.write(node_step);
			br.newLine();
			br.write("ranksep=" + rank_step);
			br.newLine();
			br.write(close);
			br.close();
		} catch (Exception e) {
		}
	}

	protected void print_node(SnipsNode node, String table, String db) {
		int tempNodeNum;
		Node_lable = getLabel(node, 1);
		String URL = "";
		if (node instanceof Skolem) {
			Skolem s = (Skolem) node;
			URL = ",URL=\"" +"/SnortSkolemReader.php?SkolemID="
					+ s.Id + "&TableName=" + table + "&DBName=" + db + "\"";
		}
		tempNodeNum=node.nodeNum+Snips3.globalNodeNum;
		try {
			br.write( tempNodeNum+ tab + label + "\"" + tempNodeNum + ": "
					+ Node_lable + "\"" + URL + "," + "fontsize="
					+ node_fontsize + "," + fontname + "," + node_fontcolor_red);
			br.newLine();
		} catch (Exception e) {
		}
	}

	public void print_arc(SnipsNode node) {
		int tempNodeNumSrc,tempNodeNumDest;
		if (!node.outGoing.isEmpty()) {
			Arcs arc = new Arcs();
			Iterator<Arcs> it;
			it = node.outGoing.iterator();
			while (it.hasNext()) {
				arc = it.next();
				tempNodeNumSrc=arc.from.nodeNum+Snips3.globalNodeNum;
				tempNodeNumDest=arc.to.nodeNum+Snips3.globalNodeNum;
				try {
					br.write(tempNodeNumSrc + "->" + tempNodeNumDest + tab
							+ label + "\"" + arc.ruleID + "\"" + ","
							+ "fontsize=" + edge_fontsize + "," + fontname
							+ "," + edge_fontcolor);
					br.newLine();
				} catch (Exception e) {
				}
			}
		}
	}

	protected String getLabel(SnipsNode node, int style) {
		String t;
		if (node instanceof Skolem) {
			Skolem s = (Skolem) node;
			t = "skolem(" + s.Id + ", " + "[" + s.Sid + ":" + s.Cid + "]"
					+ ", " + s.mode + ")";
			return t;
		}
		if (node instanceof Internal) {
			Internal in = (Internal) node;
			t = "int(" + in.fact.predicate + "(";
			t += in.fact.argsList.get(0);
			if (in.fact.argsList.size() == 2)
				t += ", " + in.fact.argsList.get(1);
			t += ")";
			if (style == 1) {
				// t += "," + in.mode + ",";
				t += "range(" + in.time.startTime + ", " + in.time.endTime
						+ ")";
			}
			t += ")";
			return t;
		} else {
			Obs o = (Obs) node;
			t = "obs(" + o.fact.predicate + ", " + "range(" + o.time.startTime
					+ ", " + o.time.endTime + "))";
			return t;
		}
	}
}
