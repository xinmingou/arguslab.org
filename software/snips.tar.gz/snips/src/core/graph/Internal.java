// Author(s) : Sathya Chandran Sundaramurthy
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.util.ArrayList;

public class Internal extends SnipsNode {
	public Fact fact;
	public Mode mode;
	public TimeRange time;
	public boolean isSkol;

	
	public Internal(Internal another) {
		super(another.nodeNum, another.inComing, new ArrayList<Arcs>(), another.visited, another.dfs_mark, another.inpath);
		this.fact = another.fact;
		this.mode = another.mode;
		this.time = another.time;
	}
	
	public Internal(Fact fact, Mode mode, TimeRange timeRange) {
		this.fact = fact;
		this.mode = mode;
		this.time = timeRange;
	}

	public Internal() {
		// TODO Auto-generated constructor stub
	}

	public Internal(int nodeNum, Fact fact, TimeRange timeRange) {
		super(nodeNum);
		this.fact = fact;
		this.time = timeRange;
	}

	void printMode() {
		System.out.println("Mode: " + mode);
	}

	public Fact getFact() {
		return fact;
	}

	public String getPredicate() {

		return fact.getPredicate();
	}

	public Mode getMode() {

		return mode;
	}

	public TimeRange getTime() {

		return time;
	}

	public boolean isSkol() {
		return isSkol;
	}

	public void setSkol(boolean isSkol) {
		this.isSkol = isSkol;
	}

	public void setFact(Fact fact) {
		this.fact = fact;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
	}

	public void setTime(TimeRange time) {
		this.time = time;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fact == null) ? 0 : fact.hashCode());
		result = prime * result + ((mode == null) ? 0 : mode.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Internal other = (Internal) obj;
		if (fact == null) {
			if (other.fact != null) {
				return false;
			}
		} else if (!fact.equals(other.fact)) {
			return false;
		}
		if (mode != other.mode) {
			return false;
		}
		if (time == null) {
			if (other.time != null) {
				return false;
			}
		} else if (!time.equals(other.time)) {
			return false;
		}
		return true;
	}

}
