// Author(s) : Kui Luo, Loai Zomlot
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.util.ArrayList;
import java.util.Iterator;

import core.main.Snips3;
import core.utils.Utilities;


public class Graph_Trim {

	public static SnipsGraph Trim(Graph g) {
		SnipsGraph output = new SnipsGraph();

		for (int i = 0; i < g.nodes.size(); i++) {
			if (!g.nodes.get(i).visited) {
				Graph temp = new Graph();
				g.nodes.get(i).Undirected_DFS(temp.nodes);
				if (Rules(temp)&&rulesComp(temp)) {    
					output.snipsgraph.add(temp);
				}
			}
		}
		return output;
	}

	static boolean Rules(Graph g) {
		int sk = 0;
		Iterator<SnipsNode> it = g.nodes.iterator();
		while (it.hasNext()) {
			if (it.next() instanceof Skolem)
				sk++;
			if (sk >= 2)
				return true;
		}
		return false;
	} 

	

	public static Graph removeExternal(Graph g) {
		ArrayList<SnipsNode> removedNodes = new ArrayList<SnipsNode>();
		for (SnipsNode node : g.nodes) {
			if (node instanceof Internal) {
				Internal in = (Internal) node;
				if ((in.fact.predicate.equals("compromised") && in.fact.argsList
						.get(0).equals("external"))) {
					for (Arcs arc : node.getInComing()) {
						arc.from.outGoing.remove(arc);
					}

					for (Arcs arc : node.getOutGoing()) {
						arc.to.inComing.remove(arc);
					}

					removedNodes.add(node);
				}
			}
		}
		g.nodes.removeAll(removedNodes);

		return g;
	}

	public static SnipsGraph removeCycle(SnipsGraph s) {
		for (int i = 0; i < s.snipsgraph.size(); i++)
			s.snipsgraph.get(i).acyclic();
		return s;
	}

	public static Graph reNumberGraph(Graph g) {
		int nodeTemp=0;
		for (SnipsNode snipsNode : g.nodes	) {
			snipsNode.nodeNum=nodeTemp++;
		}
		return g;	
	}
		
	//return true when sink is compromised else false
	static boolean rulesComp(Graph g) {
		Iterator<SnipsNode> it = g.nodes.iterator();
		while (it.hasNext()) {
			SnipsNode node =it.next();
			if (Utilities.isSink(node)){
				Internal intNode=(Internal) node;
				if(!intNode.getFact().predicate.equalsIgnoreCase("compromised")){
					return false;
				}
			}
		}
		return true;
	}

	public static SnipsGraph reNumberGraph(SnipsGraph sg) {
		int nodeTemp=0;
		for (Graph g : sg.snipsgraph) {
			for (SnipsNode snipsNode : g.nodes	) {
			snipsNode.nodeNum=nodeTemp++;
			}	
		}
		Snips3.currentGraphsNodeNumber=nodeTemp;
		return sg;	
	}


}
