// Author(s) : Sathya Chandran Sundaramurthy,Kui Luo
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.util.ArrayList;
import java.util.Iterator;

public class SnipsNode {
	public int nodeNum;
	public ArrayList<Arcs> inComing;
	public ArrayList<Arcs> outGoing;
	boolean visited = false;
	boolean dfs_mark = false;
	boolean inpath = false;
	int bn_nodenum;

	public SnipsNode() {
		inComing = new ArrayList<Arcs>();
		outGoing = new ArrayList<Arcs>();
	}

	public SnipsNode(int nodeNum) {
		this.nodeNum = nodeNum;
		inComing = new ArrayList<Arcs>();
		outGoing = new ArrayList<Arcs>();
	}

	
	public SnipsNode(int nodeNum, ArrayList<Arcs> inComing,
			ArrayList<Arcs> outGoing, boolean visited, boolean dfs_mark,
			boolean inpath) {
		this.nodeNum = nodeNum;
		this.inComing = new ArrayList<Arcs>();
		for (Arcs arcs : inComing) {
			this.inComing.add(new Arcs(arcs));	
		}
		 
		this.outGoing = outGoing;
		this.visited = visited;
		this.dfs_mark = dfs_mark;
		this.inpath = inpath;
	}

	ArrayList<SnipsNode> Undirected_DFS(ArrayList<SnipsNode> node) {
		if (!this.visited) {
			this.visited = true;
			if (!this.outGoing.isEmpty()) {
				Iterator<Arcs> it = this.outGoing.iterator();
				while (it.hasNext())
					it.next().to.Undirected_DFS(node);
			}
			if (!this.inComing.isEmpty()) {
				Iterator<Arcs> it = this.inComing.iterator();
				while (it.hasNext())
					it.next().from.Undirected_DFS(node);
			}
			node.add(this);
		}
		return node;
	}

	void Directed_DFS() {
		if (!this.visited) {
			this.inpath = true;
			if (!this.outGoing.isEmpty()) {
				for (int i = 0; i < this.outGoing.size(); i++) {
					if (!this.outGoing.get(i).to.visited
							&& this.outGoing.get(i).to.inpath) {
						this.outGoing.remove(i);
						i--;
					} else
						this.outGoing.get(i).to.Directed_DFS();
				}
			}
			this.visited = true;
		}
	}

	public ArrayList<Arcs> getIncomingArcs() {

		return inComing;
	}

	public ArrayList<Arcs> getOutGoingArcs() {

		return outGoing;
	}

	public int getNoOfIncomingArcs() {

		return inComing.size();
	}

	public int getNoOfOutGoingArcs() {

		return outGoing.size();
	}

	public boolean isIncomingNull() {

		if (inComing.isEmpty())
			return true;
		else
			return false;
	}

	public String getLabel(SnipsNode node) {

		String label = null;
		if (node instanceof Internal) {
			Internal i = new Internal();
			i = (Internal) node;
			label = i.getPredicate();
		}

		else if (node instanceof Obs) {
			Obs o = new Obs();
			o = (Obs) node;
			label = o.getPredicate();
		}

		else if (node instanceof Skolem) {
			Skolem s = new Skolem();
			s = (Skolem) node;
			label = s.getPredicate();
		}

		return label;
	}

	public String getNodeNumber() {

		return Integer.toString(nodeNum);
	}

	public void setBnNodeNumber(int bn_nodenum) {

		this.bn_nodenum = bn_nodenum;
	}

	public int getBnNodeNumber() {

		return bn_nodenum;
	}

	public int getNodeNum() {
		return nodeNum;
	}

	public void setNodeNum(int nodeNum) {
		this.nodeNum = nodeNum;
	}

	public ArrayList<Arcs> getInComing() {
		return inComing;
	}

	public void setInComing(ArrayList<Arcs> inComing) {
		this.inComing = inComing;
	}

	public ArrayList<Arcs> getOutGoing() {
		return outGoing;
	}

	public void setOutGoing(ArrayList<Arcs> outGoing) {
		this.outGoing = outGoing;
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	public boolean isDfs_mark() {
		return dfs_mark;
	}

	public void setDfs_mark(boolean dfs_mark) {
		this.dfs_mark = dfs_mark;
	}

	public boolean isInpath() {
		return inpath;
	}

	public void setInpath(boolean inpath) {
		this.inpath = inpath;
	}

	public int getBn_nodenum() {
		return bn_nodenum;
	}

	public void setBn_nodenum(int bn_nodenum) {
		this.bn_nodenum = bn_nodenum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + nodeNum;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SnipsNode other = (SnipsNode) obj;
		if (nodeNum != other.nodeNum) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "SnipsNode [nodeNum=" + nodeNum + "]";
	}

}
