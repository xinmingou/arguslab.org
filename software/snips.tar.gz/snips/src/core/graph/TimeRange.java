// Author(s) : Sathya Chandran Sundaramurthy,Kui Luo
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.sql.Timestamp;
import java.util.Date;

public class TimeRange {
	public Date startTime;
	public Date endTime;

	public TimeRange(String st, String et) {
		Long time = Long.parseLong(st.trim());
		Timestamp d = new Timestamp(time * 1000);
		this.startTime = d;
		time = Long.parseLong(et.trim());
		d = new Timestamp(time * 1000);
		this.endTime = d;
	}

	public TimeRange(Date st, Date et) {
		this.startTime = st;
		this.endTime = et;
	}

	public TimeRange() {
		// TODO Auto-generated constructor stub
	}

	void printStartTime() {
		System.out.println("Start Time: " + startTime);
	}

	void printEndTime() {
		System.out.println("End Time: " + endTime);
	}

	public Date getStartTime() {

		return startTime;
	}

	public Date getEndTime() {

		return endTime;
	}

	/**
	 * check if there is overlapping between two timeranges
	 */
	public static boolean isOverlapping(TimeRange first, TimeRange second) {
		if (first.endTime.before(second.startTime)
				|| second.endTime.before(first.startTime)) {
			return false;
		}
		return true;

	}

	/**
	 * This method take intersection of two time range if no intersection will
	 * return null. is overlapping need to be used before it.
	 * 
	 * @param t1
	 * @param t2
	 * @return Intersection of timeRange
	 */
	public static TimeRange overlapping(TimeRange t1, TimeRange t2) {

		if (t1.endTime.after(t2.endTime)) {
			TimeRange tmp = t1;
			t1 = t2;
			t2 = tmp;
		}

		if (t1.startTime.before(t2.startTime) & t1.endTime.after(t2.startTime)) {
			return new TimeRange(t2.startTime, t1.endTime);
		}

		if (t1.startTime.after(t2.startTime)) {
			return t1;
		}

		if (t1.startTime.equals(t2.startTime) & t1.endTime.equals(t2.endTime)) {
			return t1;
		}
		if (t1.startTime.equals(t2.startTime)) {
			return t1;
		}
		if (t1.endTime.equals(t2.endTime)) {
			if (t1.startTime.before(t2.startTime)) {
				return t2;
			}
			if (t1.startTime.after(t2.startTime)) {
				return t1;
			}
		}

		if (t1.endTime.equals(t2.startTime)) {
			return new TimeRange(t1.endTime, t1.endTime);
		}

		System.out.println("Error in overlapping method!");

		return null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((endTime == null) ? 0 : endTime.hashCode());
		result = prime * result
				+ ((startTime == null) ? 0 : startTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TimeRange other = (TimeRange) obj;
		if (endTime == null) {
			if (other.endTime != null) {
				return false;
			}
		} else if (!endTime.equals(other.endTime)) {
			return false;
		}
		if (startTime == null) {
			if (other.startTime != null) {
				return false;
			}
		} else if (!startTime.equals(other.startTime)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "TimeRange [startTime=" + startTime + ", endTime=" + endTime
				+ "]";
	}
}
