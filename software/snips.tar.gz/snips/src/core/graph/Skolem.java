// Author(s) : Sathya Chandran Sundaramurthy
// Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

package core.graph;

import java.util.ArrayList;

public class Skolem extends SnipsNode {
	public String Id;
	public String Cid;
	public String Sid;
	public Mode mode;

	
	public Skolem(Skolem another) {
		super(another.nodeNum, new ArrayList<Arcs>(), new ArrayList<Arcs>(), another.visited, another.dfs_mark, another.inpath);
		this.Id = another.Id;
		this.Cid = another.Cid;
		this.Sid = another.Sid;
		this.mode = another.mode;
	}

	public Skolem(int nodeNum, String id, String cid, String sid, Mode mode) {
		super(nodeNum);
		Id = id;
		Cid = cid;
		Sid = sid;
		this.mode = mode;
	}

	public Skolem() {
		// TODO Auto-generated constructor stub
	}

	void printId() {
		System.out.println(this.Id);
	}

	public String getPredicate() {

		return "skolem";
	}

	public Mode getMode() {

		return mode;
	}

	public String getSId() {

		return Sid;
	}

	public String getCId() {

		return Cid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		// int result = super.hashCode();
		int result = 1; // to remove the duplicating skolems in fact
		result = prime * result + ((Cid == null) ? 0 : Cid.hashCode());
		result = prime * result + ((Sid == null) ? 0 : Sid.hashCode());
		result = prime * result + ((mode == null) ? 0 : mode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Skolem other = (Skolem) obj;
		if (Cid == null) {
			if (other.Cid != null) {
				return false;
			}
		} else if (!Cid.equals(other.Cid)) {
			return false;
		}
		if (Sid == null) {
			if (other.Sid != null) {
				return false;
			}
		} else if (!Sid.equals(other.Sid)) {
			return false;
		}
		if (mode != other.mode) {
			return false;
		}
		return true;
	}

}
