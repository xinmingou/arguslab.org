#!/usr/bin/python
# Description:Python script to fetch the alerts from mysql database and write it
# Author(s) : Sakthiyuvaraja Sakthivelmurugan, Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import os
import time
from datetime import datetime
from datetime import timedelta
from optparse import OptionParser

try:
    import MySQLdb
except ImportError, e:
    print "MySQLdb module not found."
    sys.exit(1)
debug = False
class AlertTranslator:
    class Database:
        def __init__(self,db_host,db_user,db_pass,db_name):

            self.conn = MySQLdb.connect(host=db_host,user=db_user,passwd=db_pass,db=db_name)
            
        def fetchall(self,query):

            try:
                cursor = self.conn.cursor()
                cursor.execute(query)
                rows =  cursor.fetchall()
                cursor.close()
                return rows
            except Exception, e:
                print  e

        def fetchone(self,query):
            try:
                cursor = self.conn.cursor()
                cursor.execute(query)
                rows =  cursor.fetchone()
                cursor.close()
                return rows
            except Exception, e:
                print  e

        def execute(self, query):
            cursor = self.conn.cursor()
            cursor.execute(query)
            cursor.close()
        def __del__(self):
            self.conn.close()

#BEGIN signature class 
    class Signature:
        def __init__(self, db):
            self.sigdb = {}
            query = 'select sig_id, sig_gid, sig_sid, sig_name from signature'
            try:
                rows = db.fetchall(query)
                for row in rows:
                    self.sigdb[row[0]] = ('%d:%d'%(row[1], row[2]), row[3])
            except Exception, e:
                    print e


        def getsnortid(self, sig):
            try:
                return self.sigdb[sig][0]
            except KeyError, k:
                if debug:
                    print k
                return '0:0'
                
        def getdesc(self, sig):
            try:
                return self.sigdb[sig][1]
            except KeyError, k:
                if debug:
                    print k
                return 'Unkown'
#END signature class 

#BEGIN snipsdb functions

    def __init__(self, out_dir, start_time, 
                 end_time, time_frame,db_host,db_user,db_pass,db_name):
        try:
            self.db = AlertTranslator.Database(db_host,db_user,db_pass,db_name)
            self.sig = AlertTranslator.Signature(self.db)
        except Exception, e:
            sys.exit(e)
            
        self.out_dir = out_dir

        try:
            self.time_frame = timedelta(hours=int(time_frame))
        except ValueError, e:
            print e
            self.time_frame = datetime.timedelta(hours=1)  #was 2

        
        try:
            self.start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
        except ValueError, e:
            print e
            self.start_time = datetime.now() - self.time_frame
            
        try:
            self.end_time = datetime.strptime(end_time, "%Y-%m-%d %H:%M:%S")
        except ValueError, e:
            self.end_time = datetime.now()


    def __getfilename(self,starttime, endtime):
        FILE_PREFIX = 'obs'
        FILE_EXT = 'P'
        try:
            if starttime.minute !=0 :
                start = str(starttime.hour) + '_' +  str(starttime.minute)
            else:
                start = str(starttime.hour)
            if endtime.minute !=0 :
                end = str(endtime.hour) + '_' + str(endtime.minute)
            else:
                end = str(endtime.hour)
        except AttributeError, e:
            print e
            sys.exit(1)
        
        return "%s/%s_%sto%s.%s" %(self.out_dir, FILE_PREFIX, start,
                                  end, FILE_EXT)

    def write_obs(self):
        curr_start_time = self.start_time
        curr_end_time = curr_start_time + self.time_frame
            
        while curr_start_time < self.end_time:
            rawobs = self.fetch_alerts(curr_start_time, curr_end_time)

            if len(rawobs) != 0:
            
                obslist = self.translatealerts(rawobs)
                filename = self.__getfilename(curr_start_time, curr_end_time)

                fh = open (filename, 'w')
                for obs in obslist:
                    fh.write(obs)
                    fh.write('\n')
                fh.close()

            curr_start_time = curr_end_time
            curr_end_time = curr_start_time + self.time_frame
            

    def fetch_alerts(self, starttime, endtime):
        query = '''select e.sid, e.cid, signature, INET_NTOA(ip_src),
        INET_NTOA(ip_dst), timestamp from event e,iphdr i where e.cid
        = i.cid and e.sid = i.sid and timestamp > '%s' and timestamp < '%s' 
        order by timestamp;'''% (starttime, endtime)

       #if debug:
           # print query
        
        rawalerts = self.db.fetchall(query)
        
        return rawalerts

    def translatealerts(self,rawobslist):

        if rawobslist is None:
            return None

        obslist = []
        for ro in rawobslist:
            snortid = self.sig.getsnortid(ro[2])
            obs = '''obs(oid(%d,%d), snort('%s', '%s', '%s', %s)).''' % (ro[0],ro[1], snortid, ro[3], ro[4], unixtime(ro[5]))
            obslist += [obs]

        return obslist
        
def unixtime(timestamp):
    return int (time.mktime(timestamp.timetuple()))


def main(cliargs):
    oparser = OptionParser()
    oparser.add_option("-d", "--out-dir", dest="out_dir",
                       help="store the output files to this directory",
                       default=os.getcwd())
    oparser.add_option("-s", "--start-time", dest="start_time",
                       help="starting time of the alerts", default="")
    oparser.add_option("-f", "--time-frame", dest="time_frame",
                       help="alerts are grouped in this timeframe", default=1)
    oparser.add_option("-e", "--end-time", dest="end_time",
                       help="end time of the alerts", default="")
    oparser.add_option("-o", "--db-host", dest="db_host",
                       help="host name for db", default="")
    oparser.add_option("-u", "--db-username", dest="db_user",
                       help="datatbase user name", default="")
    oparser.add_option("-p", "--db-pass", dest="db_pass",
                       help="datatbase user pass", default="")
    oparser.add_option("-n", "--db-name", dest="db_name",
                       help="datatbase name", default="")

    (options, args) = oparser.parse_args(cliargs)

#    print options
    at = AlertTranslator(out_dir=options.out_dir, 
                         start_time=options.start_time,
                         end_time=options.end_time,
                         time_frame=options.time_frame,
                         db_host=options.db_host,
                         db_user=options.db_user,
                         db_pass=options.db_pass,
                         db_name=options.db_name)
    
    at.write_obs()
    
if __name__ == '__main__':
    main(sys.argv[1:])

