#!/bin/bash     
# Description: Get the alerts from db then translate and summerize them
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf

if [ "$#" -ne "4" ];
   then
         echo "Usage:$0 start_time end_time "
	 echo "eg: ./preprocess_alerts.sh 2010-08-26 10:00:00 2010-08-26 11:00:00"
	 echo "DO NOT SEND IN MORE THAN TWO HOURS' DATA!"
	 exit 0 
fi

start_date=$1
start_time=$2
end_date=$3
end_time=$4

### clean up ###
rm -f $SNIPS_ROOT/bin/obs_*.P

### get and translate snort alerts ###
python $SNIPS_ROOT/src/aux/alert_translator2.py -s "$start_date $start_time" -e "$end_date $end_time" -f 1 -o "$db_host" -u "$db_user" -p "$db_pass" -n "$db_name" -d $SNIPS_ROOT/bin/
cat $SNIPS_ROOT/bin/obs_*to*.P > $SNIPS_ROOT/bin/obs_total.P

### summerizing the observations ###
sh $SNIPS_ROOT/src/aux/summary_db3.sh $SNIPS_ROOT/bin/obs_total.P  

### clean up ###
rm -f $SNIPS_ROOT/bin/obs_*.P


