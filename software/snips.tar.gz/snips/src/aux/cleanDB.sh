# !/bin/sh
# This script will clean all snips tables.
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

. $SNIPS_ROOT/snips.conf  


mysql --user=$db_user --password=$db_pass --host=$db_host $db_name -A <<EOF
TRUNCATE  $graphs_nodes_table;
TRUNCATE  $graphs_arcs_table; 
TRUNCATE  $skolem_map_table; 
TRUNCATE  $global_num_table; 
TRUNCATE  $alerts_table; 
TRUNCATE  $summary_table; 
TRUNCATE  $summary_proof_step_table; 
TRUNCATE  $internal_proof_step_table; 
EOF
