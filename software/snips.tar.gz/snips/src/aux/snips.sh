#!/bin/sh
# main SnIPS script that call preprocessing then reasoning
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


. $SNIPS_ROOT/snips.conf

if [ "$#" -ne "4" ];
   then
         echo "usage: sh $0 start_date start_time end_date end_time"  
         echo "example: sh $0 2011-12-11 10:00:00 2011-12-11 16:00:00"
	 exit 0 
fi

start_date=$1
start_time=$2
end_date=$3
end_time=$4

#clean db
sh $SNIPS_ROOT/src/aux/cleanDB.sh
find $SNIPS_ROOT/bin -name '*.dot' | xargs rm -f
find $SNIPS_ROOT/bin -name 'obs_*.P' | xargs rm -f

##getting alerts and summarize them##
echo
printf "preprocessing stage"
##check if will take time
mysql --user=$db_user --password=$db_pass --host=$db_host $db_name -A <<EOF
select if ((select count(*) from event where timestamp >=  "$start_date $start_time" and timestamp <= "$end_date $end_time") >= 200000,'The pre-processing stage may take several minutes for large alerts input(e.g. 200k alerts or more). The user can avoid this delay by accumulating the pre-processing results in hourly bases using cron job. The user can contact us at snips-feedback@projects.cis.ksu.edu for further help in this regards.' ,'') as ''
EOF

printf "please be patient with us"
sh  $SNIPS_ROOT/src/aux/mulPreprocess.sh 1 $start_date $start_time $end_date $end_time 

##reasoning and output the graphs###
echo
printf "reasoning stage"
sh  $SNIPS_ROOT/src/aux/reasoning3.sh  $start_date $start_time $end_date $end_time 
echo
echo "done"
echo
echo "$(tput setaf 2) find the output in \"http://localhost/snipsInterface/snipsMain.html\" $(tput sgr0)"
echo


