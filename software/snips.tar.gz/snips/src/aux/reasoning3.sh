#!/bin/bash     
# Description: This script gets the summerized facts from db and reason about them. Then it creates proof steps and stores them in db
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf

if [ "$#" -ne "0" ];
then
    if [ "$#" -ne "4" ];
    then
        echo "Usage: $0 [start_time] [end_time].
         example: reasoning3.sh [2010-08-26] [10:00:00] [2010-08-26] [11:00:00]
         start_time and end_time are optional"
	exit 0 
    fi
fi

logfile="$SNIPS_ROOT/bin/reasoning_xsb.log"
MappingDBHandle="snips"
dotfile="$SNIPS_ROOT/bin/*.dot"
start_date=$1
start_time=$2
end_date=$3
end_time=$4


##get the start time and date in epoch time
getEpoch(){
    date=$1
    time=$2
    date_epoch=$(date +'%s' -d $date)
    h=${time%%:*}
    hm=${time%:*}
    m=${hm#*:}
    s=${time##*:}
    time_sec=$(expr $h \* 3600 \+ $m \* 60 \+ $s)
    date_time_epoch=$(expr $date_epoch \+ $time_sec)
    echo $date_time_epoch
}

callXSB(){
    xsb 2> $logfile 1>&2 <<EOF
['$SNIPS_ROOT/kb/obsMap_snort.P'].
['$SNIPS_ROOT/src/core/analysis/libutils.P'].
['$SNIPS_ROOT/src/core/analysis/mode.P'].
['$SNIPS_ROOT/kb/internal_model3.P'].
['$SNIPS_ROOT/src/core/analysis/reason.P'].
[dbdrivers].
load_driver(mysql).
db_connect($MappingDBHandle, mysql, $db_host, $db_name,'$db_user','$db_pass').
$1
db_disconnect($MappingDBHandle).
halt.
EOF
}

printf "..."
if [ "$#" -eq "0" ];
then
    callXSB "createProofStepsFormDB(_Query)."

elif [ "$#" -eq "4" ];then

    start_date_time_epoch=$(getEpoch $start_date $start_time)
    end_date_time_epoch=$(getEpoch $end_date $end_time)

    callXSB "createProofStepsFormDB(_Query,$start_date_time_epoch,$end_date_time_epoch)."

fi

printf "..."
##create the graph ##
java -cp $SNIPS_ROOT/bin:$SNIPS_ROOT/lib/mysql-connector-java-5.1.18-bin.jar core.main.Snips3 $SNIPS_ROOT/snips.conf

if [ ! -s $dotfile ]; then
    echo "Error in creating graph structure in Java."
    exit 1
else
    dot -Tsvg $SNIPS_ROOT/bin/*.dot -o $SNIPS_ROOT/bin/snips_graph_ds.svg
fi
printf "..."


 ### clean up ###
chmod 644 $SNIPS_ROOT/bin/*.svg
if [ -w $apache_dir/snipsInterface ] 
then
    mv $SNIPS_ROOT/bin/*.svg $apache_dir/snipsInterface
else
    echo  "copying results to $apache_dir/snipsInterface will need higher priviliges!"
    mv $SNIPS_ROOT/bin/*.svg $apache_dir/snipsInterface
fi
rm $SNIPS_ROOT/bin/*.dot
