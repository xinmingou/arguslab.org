#!/bin/bash     
# This scripts invokes xsb for summarization.
# it takes input as observation file (obs.P) and write the 
# the suumarized facts in db at snips_summary table
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf


if [ "$#" -ne "1" ];
then
    echo "usage: $0 <obs_file>"
    exit 0
fi

obsfile=$1
logfile="$SNIPS_ROOT/bin/summarizing_xsb.log"
MappingDBHandle="snips"

xsb 2> $logfile 1>&2 <<EOF
['$SNIPS_ROOT/kb/obsMap_snort.P'].
['$SNIPS_ROOT/hostConfig.P'].
['$SNIPS_ROOT/src/core/analysis/libutils.P'].
['$SNIPS_ROOT/src/core/analysis/summary_db3.P'].
load_dyn('$obsfile').
[dbdrivers].
load_driver(mysql).
db_connect($MappingDBHandle, mysql, $db_host, $db_name,'$db_user','$db_pass').
summarize.
db_disconnect($MappingDBHandle).
halt.
EOF

