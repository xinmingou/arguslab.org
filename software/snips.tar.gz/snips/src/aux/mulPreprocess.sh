#!/bin/sh
#this script will be calling preprocess3 multiple times.
# Author(s) : Loai Zomlot 
# Copyright (C) 2012, Argus Cybersecurity Lab, Kansas State University

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $SNIPS_ROOT/snips.conf

if [ "$#" -ne "5" ];
   then
         echo "usage:$0" '"period in hours" start_date start_time end_date end_time'
	 echo "eg:$0" ' 2 start_date start_time end_date end_date summTable skolemTable'
	 exit 0 
fi

period=$1
input_start_date=$2 
input_start_time=$3
input_end_date=$4 
input_end_time=$5

##get the start time and date in epoch time
getEpoch(){
date=$1
time=$2
date_epoch=$(date +'%s' -d $date)
h=${time%%:*}
hm=${time%:*}
m=${hm#*:}
s=${time##*:}
time_sec=$(expr $h \* 3600 \+ $m \* 60 \+ $s)
date_time_epoch=$(expr $date_epoch \+ $time_sec)
echo $date_time_epoch
}

###getting and calculate time and format it###
input_end_date_time_sec=$(getEpoch $input_end_date $input_end_time)

period_sec=$(expr $period \* 3590)
start_date_time_sec=$(getEpoch $input_start_date $input_start_time)
condition=$(expr $start_date_time_sec + $period_sec)

while [ $condition -lt $input_end_date_time_sec ]
do
printf "....."
end_date_time_sec=$(expr $start_date_time_sec + $period_sec)
start_date=$(date -d @$start_date_time_sec +'%Y-%m-%d') 
start_time=$(date -d @$start_date_time_sec +'%H:%M:%S')
end_date=$(date -d @$end_date_time_sec +'%Y-%m-%d') 
end_time=$(date -d @$end_date_time_sec +'%H:%M:%S')

##getting alerts and summarize them##
sh  $SNIPS_ROOT/src/aux/preprocess_alerts3.sh $start_date $start_time $end_date $end_time 
start_date_time_sec=$end_date_time_sec 
condition=$(expr $start_date_time_sec + $period_sec)
done

